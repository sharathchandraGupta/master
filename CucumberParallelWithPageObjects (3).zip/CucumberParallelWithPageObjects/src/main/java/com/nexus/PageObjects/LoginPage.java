package com.nexus.PageObjects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;

import com.nexus.utilities.DriverManager;



public class LoginPage extends BasePage {
		
	
	public String searchBox = "//*[@name='q']";
	
	public LoginPage open(String url) {
	
		System.out.println("Page Opened");
		DriverManager.getDriver().get(url);
		return (LoginPage) openPage(LoginPage.class);
	}
	
	public void searchSelenium(String str){
		System.out.println("inside go to login");
		WebElement eleSearchBox = DriverManager.getDriver().findElement(By.xpath(searchBox));
		type(eleSearchBox, str, "searchBox");	
		try {
			Thread.sleep(10000);
		}catch(Exception e) {
			
		}
	}

	@Override
	protected ExpectedCondition getPageLoadCondition() {
		// TODO Auto-generated method stub
		return null;
	}
	
	
}

