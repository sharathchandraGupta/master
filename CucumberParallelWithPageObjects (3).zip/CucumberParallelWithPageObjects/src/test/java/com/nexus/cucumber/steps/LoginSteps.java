package com.nexus.cucumber.steps;

import com.aventstack.extentreports.Status;
import com.nexus.PageObjects.LoginPage;

import cucumber.api.Scenario;
import cucumber.api.java.After;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class LoginSteps  extends BaseSteps{
	
	@Before
	public synchronized void  before(Scenario scenario) {	
		setUpFramework();
	}

	@After
	public void after(Scenario scenario) {
		quit();

	}

	
	@Given("^launch browser 'chrome'$")
	public void launch_browser_chrome() throws Throwable {
		openBrowser("chrome");
		
	}

	@When("^user navigates to the URL 'http://google\\.com'$")
	public void user_navigates_to_the_URL_http_google_com() throws Throwable {
		LoginPage loginPage = new LoginPage();
		loginPage.open("http://www.google.com");
		Thread.sleep(5000);
		loginPage.searchSelenium("Selenium");
	
	}

	@Then("^user click on login$")
	public void user_click_on_login() throws Throwable {
	   System.out.println("");
	}
}
