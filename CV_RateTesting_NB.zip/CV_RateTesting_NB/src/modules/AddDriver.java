package modules;

import java.io.FileOutputStream;

import org.apache.poi.xwpf.usermodel.XWPFDocument;
import org.apache.poi.xwpf.usermodel.XWPFRun;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.testng.Assert;

import utils.Parameters;
import utils.Reusable_Methods;

public class AddDriver {
	WebDriver driver;
	pages.AddDriver d;
	Reusable_Methods RM;

	public AddDriver(WebDriver webdriver) {
		driver = webdriver;
		d = new pages.AddDriver(driver);
		RM = new Reusable_Methods(driver);

	}

	public void AddDriver(XWPFDocument docx,XWPFRun run,FileOutputStream out) throws Exception {
		int drivers =  Parameters.DriversToBeAdded;
	for(int i=0;i<drivers;i++){	
		JavascriptExecutor js = (JavascriptExecutor) driver;
		Thread.sleep(3000);
		d.AddDriver.click();
		
		
		Thread.sleep(3000);
		try {
			driver.switchTo().frame(0);
		} catch (Exception e) {

		}
		boolean flag = RM.verify_PageTitle(driver, "Add Driver");
		
		try {
			Assert.assertEquals(flag, true);
		} catch (AssertionError e) {
			e.printStackTrace();
			System.out.println("Failed to Navigate to Add Driver Screen");
			
		}
		
		d.FirstName.sendKeys(Parameters.FirstName.split("#")[i]);
		d.MiddleName.sendKeys(Parameters.MiddleName.split("#")[i]);
		d.LastName.sendKeys(Parameters.LastName.split("#")[i]);
			
		d.Gender.sendKeys(Parameters.Gender.split("#")[i]);
		d.Gender.sendKeys(Keys.TAB);
		Thread.sleep(2000);
		
		d.DateOfBirth.sendKeys(Parameters.DateOfBirth.split("#")[i]);
		Thread.sleep(1000);
		d.DateOfBirth.sendKeys(Keys.TAB);
		Thread.sleep(3000);
		
		try{			
			d.MaritalStatus.sendKeys(Parameters.MaritalStatus.split("#")[i].trim());
			Thread.sleep(2000);
			d.MaritalStatus.sendKeys(Keys.TAB);		
			Thread.sleep(2000);
		}catch(Exception e){
			
		}
		
		d.Province.sendKeys(Parameters.Province.split("#")[i]);
		d.Province.sendKeys(Keys.TAB);
		Thread.sleep(1000);
		RM.captureScreenShot(docx,run,out);
		try {
			d.LicenseNumber.sendKeys(Parameters.LicenseNumber.split("#")[i]);
			d.LicenseNumber.sendKeys(Keys.TAB);
		} catch (Exception e) {
		}
		Thread.sleep(2000);

		d.LicenseClass.sendKeys(Parameters.LicenseClass.split("#")[i]);
		d.LicenseClass.sendKeys(Keys.TAB);
		Thread.sleep(2000);
		
		d.DateAchieved.sendKeys(Parameters.DateAchieved.split("#")[i]);
		d.DateAchieved.sendKeys(Keys.TAB);
		String achievedDate = d.DateAchieved.getText();
		Thread.sleep(2000);
		
		//To add conviction and driving retraining, student away form home
		if(Parameters.AddConvention.split("#")[i].equalsIgnoreCase("YES")){
			String[] conviction_Type = Parameters.AddConvention_Desc_Type.split("_")[i].split("#");
			
			for(int conv = 0;conv<conviction_Type.length;conv++){
				
				js.executeScript("arguments[0].scrollIntoView(true)",d.Add_Conviction);
				d.Add_Conviction.click();
				Thread.sleep(2000);
								
				d.ConvictionInput_Code.get(conv).sendKeys(conviction_Type[conv]);
				Thread.sleep(1000);
				d.ConvictionInput_Code.get(conv).sendKeys(Keys.TAB);
				Thread.sleep(1000);
				
				d.ConvictionInput_ConvictionDate.get(conv).sendKeys(Parameters.AddConvention_Date.split("#")[conv]);
				Thread.sleep(1000);
				d.ConvictionInput_ConvictionDate.get(conv).sendKeys(Keys.TAB);	
				Thread.sleep(1000);
				
				if(!Parameters.AddConviction_OffenceDate.isEmpty()){
					d.ConvictionInput_OffenceDate.get(conv).sendKeys(Parameters.AddConviction_OffenceDate.split("#")[conv]);
					Thread.sleep(1000);
					d.ConvictionInput_OffenceDate.get(conv).sendKeys(Keys.TAB);
					Thread.sleep(1000);
				}
			}
		}
		
		//To add suspension date
		if(Parameters.AddSuspension.split("#")[i].equalsIgnoreCase("YES")){
			String[] susp_Type = Parameters.AddSuspension_Desc_Type.split("_")[i].split("#");
			
			for(int sus = 0;sus<susp_Type.length;sus++){
				
				js.executeScript("arguments[0].scrollIntoView(true)",d.Add_Suspension);
				d.Add_Suspension.click();
				Thread.sleep(2000);
								
				d.Suspension_Description.get(sus).sendKeys(susp_Type[sus]);
				d.Suspension_Description.get(sus).sendKeys(Keys.TAB);
				Thread.sleep(1000);
				
				d.Suspension_SuspensionDate.get(sus).sendKeys(Parameters.AddSuspension_Date.split("#")[sus]);
				d.Suspension_SuspensionDate.get(sus).sendKeys(Keys.TAB);	
				Thread.sleep(1000);
				
				d.Suspension_SuspensionDate.get(sus).sendKeys(Parameters.AddSuspension_Date.split("#")[sus]);
				d.Suspension_SuspensionDate.get(sus).sendKeys(Keys.TAB);	
				Thread.sleep(1000);
				
				if(!Parameters.AddSuspension_ReinstatementDate.isEmpty()){
					d.Suspension_ReinstatementDate.get(sus).sendKeys(Parameters.AddSuspension_ReinstatementDate.split("#")[sus]);
					d.Suspension_ReinstatementDate.get(sus).sendKeys(Keys.TAB);
					Thread.sleep(1000);
				}
			}
		}
		/*if(Parameters.Driver_ReTraining.split("#")[i].equalsIgnoreCase("YES")){
			js.executeScript("arguments[0].scrollIntoView(true)",d.DriverInput_Retraining_Yes);
			d.DriverInput_Retraining_Yes.click();
			RM.wait_For_Element(d.DriverInput_RetrainingDate);
			Thread.sleep(1000);
			d.DriverInput_RetrainingDate.sendKeys(Parameters.DriverTraining_CompldtedDate.split("#")[i]);
			d.DriverInput_RetrainingDate.sendKeys(Keys.TAB);
		}
		
		if(Parameters.StudentawayfromHome.equalsIgnoreCase("YES")){
			d.DriverInput_StudentAwayFromHome_Yes.click();			
		}
		
		if(Parameters.DriverTraining.split("#")[i].equalsIgnoreCase("YES")){
			d.DriverTraining_Yes.click();
			RM.wait_For_Element(d.DriverInput_TrainingCompletedDate);
			Thread.sleep(1000);
			d.DriverInput_TrainingCompletedDate.sendKeys(Parameters.DriverReTraining_CompldtedDate.split("#")[i]);
			d.DriverInput_TrainingCompletedDate.sendKeys(Keys.TAB);
			
		}
*/
		RM.captureScreenShot(docx,run,out);
		js.executeScript("window.scrollBy(0,1500)");
		js.executeScript("arguments[0].scrollIntoView",driver.findElement(By.xpath("//*[@class='g-btn-text'][contains(text(),'Save')]")));
		driver.findElement(By.xpath("//*[@class='g-btn-text'][contains(text(),'Save')]")).click();
		Thread.sleep(5000);		
		}
	RM.captureScreenShot(docx,run,out);
	JavascriptExecutor js = (JavascriptExecutor) driver;
	js.executeScript("window.scrollBy(0,1500)");
	driver.findElement(By.xpath("//*[@class='g-btn-text'][contains(text(),'Next')]")).click();
	Thread.sleep(6000);
	}	
	
					
}
