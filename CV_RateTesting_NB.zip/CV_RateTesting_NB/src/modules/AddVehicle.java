package modules;

import java.io.FileOutputStream;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import org.apache.poi.xwpf.usermodel.XWPFDocument;
import org.apache.poi.xwpf.usermodel.XWPFRun;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.Assert;

import utils.Parameters;
import utils.Reusable_Methods;

public class AddVehicle {
	WebDriver driver;
	pages.AddVehicle v;
	Reusable_Methods RM;
	String Added_Vehicles="";	
	JavascriptExecutor js ;
	
	public AddVehicle(WebDriver webdriver) {
		driver = webdriver;
		v = new pages.AddVehicle(driver);
		js = (JavascriptExecutor) driver;
		RM = new Reusable_Methods(driver);
	}

	public void AddVehicle(XWPFDocument docx,XWPFRun run,FileOutputStream out) throws Exception {
		
		for(int cv =0;cv<Parameters.Vehicle_CV_Count;cv++){
			add_Commercial_Vehicle(cv,docx,run,out);	
		}
		
		for(int non =0;non<Parameters.Vehicle_NonOwned_Count;non++){
			add_NonOwned_Vehicle(non, docx, run, out);	
		}
		
		Thread.sleep(6000);
		((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView", driver.findElement(By.xpath("//*[@class='g-btn-text'][contains(text(),'Next')]")));
		RM.captureScreenShot(docx,run,out);
		driver.findElement(By.xpath("//*[@class='g-btn-text'][contains(text(),'Next')]")).click();		
		Thread.sleep(6000);
	}
	
	public void add_Commercial_Vehicle(int k, XWPFDocument docx,XWPFRun run,FileOutputStream out) throws InterruptedException {
		try {
			RM.wait_For_Element(v.AddVehicle);
			Thread.sleep(5000);
			v.AddVehicle.click();
			Thread.sleep(2000);
			try {
				driver.switchTo().frame(0);
			} catch (Exception e) {

			}
			boolean flag = RM.verify_PageTitle(driver, "Vehicle Lookup Screen");
			try {
				Assert.assertEquals(flag, true);
			} catch (AssertionError e) {
				e.printStackTrace();
				System.out.println("Failed to Navigate to Vehicle Lookup Screen");
			}

			v.CommercialUse.clear();
			v.CommercialUse.sendKeys("Commercial Vehicle");
			v.CommercialUse.sendKeys(Keys.TAB);	
			
			//To select the vechicel type
			RM.wait_For_Element(v.Year);
			Thread.sleep(1000);
			
			
			if (Parameters.VVIN_Flag.split("#")[k].equalsIgnoreCase("VINCode")) {
				v.VIN.sendKeys(Parameters.VIN.split("#")[k]);
				v.VIN.sendKeys(Keys.TAB);
				RM.wait_For_Element(v.search_Vehicle_VIN);
				Thread.sleep(3000);
				v.search_Vehicle_VIN.click();
				Thread.sleep(3000);				
			}else if(Parameters.VVIN_Flag.split("#")[k].equalsIgnoreCase("carcode")){
				v.VICC.sendKeys(Parameters.VIN.split("#")[k]);
				v.VICC.sendKeys(Keys.TAB);
				RM.wait_For_Element(v.search_Vehicle_CarCode);
				Thread.sleep(3000);
				v.search_Vehicle_CarCode.click();
				Thread.sleep(3000);	
			}else{
				v.Year.sendKeys(Parameters.CV_Year.split("#")[k]);
				Thread.sleep(1000);	
				v.Make.sendKeys(Parameters.CV_Make.split("#")[k]);
				Thread.sleep(1000);	
				v.Make.sendKeys(Keys.TAB);
				Thread.sleep(2000);
				v.Model.sendKeys(Parameters.CV_Model.split("#")[k]);
				Thread.sleep(1000);	
				v.Model.sendKeys(Keys.TAB);
				Thread.sleep(1000);	
				v.search_Vehicle.click();
				Thread.sleep(2000);
			}
				try {
					
					driver.switchTo().frame(0);
					/*driver.findElements(By.className("g-btn-text")).get(0).click();*/
				for(int a=0;a<v.VINService_Vehicle_Years.size();a++){
						if(v.VINService_Vehicle_Years.get(a).getText().equals(Parameters.CV_Year.split("#")[k])){						
							((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true)",driver.findElements(By.className("g-btn-text")).get(a));
							driver.findElements(By.className("g-btn-text")).get(a).click();	
						}
				}
					Thread.sleep(4000);
					try {
						driver.switchTo().window(" ");
						driver.switchTo().frame(driver.findElement(By.tagName("iframe")).getAttribute("name"));
					} catch (Exception e) {
						driver.switchTo().frame(driver.findElement(By.tagName("iframe")).getAttribute("name"));
					}
					Thread.sleep(3000);
					RM.captureScreenShot(docx,run,out);
					RM.wait_For_Element(v.Add);
					try {
						v.VehicleType.sendKeys(Parameters.CV_VehicleType.split("#")[k]);
						Thread.sleep(2000);
						v.VehicleType.sendKeys(Keys.TAB);
						Thread.sleep(2000);
					} catch (Exception e) {
						
					}
					v.Add.click();
				} catch (Exception e) {
					Thread.sleep(4000);
					try {
						driver.switchTo().window(" ");
						driver.switchTo().frame(driver.findElement(By.tagName("iframe")).getAttribute("name"));
					} catch (Exception e1) {
						driver.switchTo().frame(driver.findElement(By.tagName("iframe")).getAttribute("name"));
					}
					Thread.sleep(3000);
					RM.captureScreenShot(docx,run,out);
					try {
						try {
							v.VehicleType.sendKeys(Parameters.CV_VehicleType.split("#")[k]);
							Thread.sleep(2000);
							v.VehicleType.sendKeys(Keys.TAB);
							Thread.sleep(2000);
						} catch (Exception e2) {
							
						}
						
						v.Add.click();
					} catch (Exception e4) {

					}
				}
												
				Thread.sleep(4000);
				boolean flag1 = RM.verify_PageTitle(driver, "Commercial Vehicle Details");
				try {
					Assert.assertEquals(flag1, true);
				} catch (AssertionError f) {
					f.printStackTrace();
					System.out.println("Failed to Navigate to Commercial Vehicle Details Screen");
					js.executeScript("window.scrollBy(0,1500)");
				}
				
				DateFormat dateFormat = new SimpleDateFormat("YYYY-MM-DD");
				Date date = new Date();
				String date1 = dateFormat.format(date);
				if(Parameters.OwnerShipType.split("#")[k].equalsIgnoreCase("Leased")){
					v.OwnershipType.clear();
					v.OwnershipType.sendKeys(Parameters.
							OwnerShipType.split("#")[k]);
					Thread.sleep(1000);
					v.OwnershipType.sendKeys(Keys.TAB);
					Thread.sleep(3000);						
					try {
						v.LeasedDate.sendKeys(date1);
						v.LeasedDate.sendKeys(Keys.TAB);
					} catch (Exception e1) {						
					}
					Thread.sleep(1000);
				}else{					
					v.OwnershipType.clear();
					Thread.sleep(1000);	
					v.OwnershipType.sendKeys(Parameters.OwnerShipType.split("#")[k]);
					Thread.sleep(1000);
					v.OwnershipType.sendKeys(Keys.TAB);
					Thread.sleep(1000);
					try {
						if(v.PurchaseDate.isDisplayed()){
							v.PurchaseDate.sendKeys(Parameters.PurchaseDate.split("#")[k]);
						}
					} catch (Exception e1) {
					}
				}
				
				if(Parameters.CV_VehicleType.split("#")[k].toUpperCase().contains("TRAILER")){
					trailler_Vehicle(k);
				}else{
					driver.findElement(By.xpath("//*[@fieldref='RiskVehicleInput.LocationOfUse']")).clear();
					Thread.sleep(1000);
					driver.findElement(By.xpath("//*[@fieldref='RiskVehicleInput.LocationOfUse']")).sendKeys(Parameters.LocationOfUse.split("#")[k]);
					Thread.sleep(1000);
					driver.findElement(By.xpath("//*[@fieldref='RiskVehicleInput.LocationOfUse']")).sendKeys(Keys.TAB);
					Thread.sleep(1000);
					driver.findElement(By.xpath("//*[@fieldref='RiskCommercialAutoInput.LocationSearch']")).sendKeys(Parameters.CV_LocationOfUse_PostalCode.split("#")[k]);
					
					try {
						driver.findElement(By.xpath("//img[@class='g-btn-img-loneIcon']")).click();
						Thread.sleep(20000);
					} catch (Exception e1) {
					}
					try {
						driver.switchTo().frame(0);
						driver.findElements(By.className("g-btn-text")).get(0).click();
						Thread.sleep(3000);

						try {
							driver.switchTo().window(" ");
							driver.switchTo().frame(driver.findElement(By.tagName("iframe")).getAttribute("name"));
						} catch (Exception es) {
							driver.switchTo().frame(driver.findElement(By.tagName("iframe")).getAttribute("name"));
						}
					} catch (Exception e2) {
					}
				
				}
				
				RM.wait_For_Element(v.TypeOfCommercialUse);
				v.TypeOfCommercialUse.sendKeys(Parameters.CV_TypeOfCommercialUse.split("#")[k]);
				Thread.sleep(2000);
				v.TypeOfCommercialUse.sendKeys(Keys.TAB);
				RM.wait_For_Element(v.CommoditiesCarried);
				Thread.sleep(1000);
				try{
					if(v.CommoditiesCarried.isDisplayed()){
					v.CommoditiesCarried.sendKeys(Parameters.CV_CommoditiesCarried.split("#")[k].trim());
					Thread.sleep(2000);
					v.CommoditiesCarried.sendKeys(Keys.TAB);	
					Thread.sleep(3000);
					}
				}catch(Exception e3){
					
				}
				
				Thread.sleep(3000);
				
				
				try {
					
						if(Parameters.CV_RateByValue.split("#")[k].equalsIgnoreCase("YES")){
							try {
								((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true)", v.RateByValue);
								if(!v.RateByValue.isSelected()){
									v.RateByValue.click();	
								}
								
								Thread.sleep(2000);
								} catch (Exception e) {	
							System.out.println("rate by value is not displayed");
								}
								
										
						}
				
				} catch (Exception e) {
					
				
				}
				
				
//				**************************************************
				try {
					if(!Parameters.MonthsInUS.isEmpty()){					
						Thread.sleep(2000);
						v.RiskCVInput_MonthsInUS.clear();
						Thread.sleep(1000);
						v.RiskCVInput_MonthsInUS.sendKeys(Parameters.MonthsInUS.split("#")[k]);
						Thread.sleep(1000);
						v.RiskCVInput_MonthsInUS.sendKeys(Keys.TAB);
						Thread.sleep(1000);
					}
				} catch (Exception e) {
			
				}	
//				**************************************************
				v.RadiusOfOperation.sendKeys(Parameters.CV_RadiusOfOperation.split("#")[k]);
				
				
				v.ListPriceNew.sendKeys(Parameters.CV_ListPriceNew.split("#")[k]);
				
				
				RM.captureScreenShot(docx,run,out);
				((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", v.Save);
				v.Save.click();
				driver.switchTo().defaultContent();
				boolean flag2 = RM.verify_PageTitle(driver, "Vehicle");
				try {
					Assert.assertEquals(flag2, true);
				} catch (AssertionError g) {
					g.printStackTrace();
					System.out.println("Failed to Navigate to Vehicle Screen");
				}
			}catch(Exception laste){
				laste.printStackTrace();
			}
		
	}

	
	public void add_Commercial_Vehicle(int non, XWPFDocument docx,XWPFRun run,FileOutputStream out,int t) throws InterruptedException {
		try {
			int k=non;
		
			v.CommercialUse.clear();
			v.CommercialUse.sendKeys("Commercial Vehicle");
			v.CommercialUse.sendKeys(Keys.TAB);	
			
			//To select the vechicel type
			RM.wait_For_Element(v.Year);
			Thread.sleep(1000);
			v.VehicleType.sendKeys(Parameters.CV_VehicleType.split("#")[k]);
			v.VehicleType.sendKeys(Keys.TAB);
			
			if (Parameters.VVIN_Flag.split("#")[k].equalsIgnoreCase("yes")) {
				v.VIN.sendKeys(Parameters.VIN.split("#")[k]);
				v.VIN.sendKeys(Keys.TAB);
				RM.wait_For_Element(v.search_Vehicle_VIN);
				Thread.sleep(3000);
				v.search_Vehicle_VIN.click();
				Thread.sleep(3000);				
			}else {
				v.Year.sendKeys(Parameters.CV_Year.split("#")[k]);
				Thread.sleep(1000);	
				v.Make.sendKeys(Parameters.CV_Make.split("#")[k]);
				Thread.sleep(1000);	
				v.Make.sendKeys(Keys.TAB);
				Thread.sleep(2000);
				v.Model.sendKeys(Parameters.CV_Model.split("#")[k]);
				Thread.sleep(1000);	
				v.Model.sendKeys(Keys.TAB);
				Thread.sleep(1000);	
				v.search_Vehicle.click();
				Thread.sleep(2000);
			}
				try {
					
					driver.switchTo().frame(0);
					/*driver.findElements(By.className("g-btn-text")).get(0).click();*/
				for(int a=0;a<v.VINService_Vehicle_Years.size();a++){
						if(v.VINService_Vehicle_Years.get(a).getText().equals(Parameters.CV_Year.split("#")[k])){						
							((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true)",driver.findElements(By.className("g-btn-text")).get(a));
							driver.findElements(By.className("g-btn-text")).get(a).click();	
						}
				}
					Thread.sleep(4000);
					try {
						driver.switchTo().window(" ");
						driver.switchTo().frame(driver.findElement(By.tagName("iframe")).getAttribute("name"));
					} catch (Exception e) {
						driver.switchTo().frame(driver.findElement(By.tagName("iframe")).getAttribute("name"));
					}
					Thread.sleep(3000);
					RM.captureScreenShot(docx,run,out);
					RM.wait_For_Element(v.Add);
					v.Add.click();
				} catch (Exception e) {
					Thread.sleep(4000);
					try {
						driver.switchTo().window(" ");
						driver.switchTo().frame(driver.findElement(By.tagName("iframe")).getAttribute("name"));
					} catch (Exception e1) {
						driver.switchTo().frame(driver.findElement(By.tagName("iframe")).getAttribute("name"));
					}
					Thread.sleep(3000);
					RM.captureScreenShot(docx,run,out);
					try {
						v.Add.click();
					} catch (Exception e4) {

					}
				}
												
				Thread.sleep(4000);
				boolean flag1 = RM.verify_PageTitle(driver, "Commercial Vehicle Details");
				try {
					Assert.assertEquals(flag1, true);
				} catch (AssertionError f) {
					f.printStackTrace();
					System.out.println("Failed to Navigate to Commercial Vehicle Details Screen");
					js.executeScript("window.scrollBy(0,1500)");
				}
				
				DateFormat dateFormat = new SimpleDateFormat("YYYY-MM-DD");
				Date date = new Date();
				String date1 = dateFormat.format(date);
				if(Parameters.OwnerShipType.split("#")[k].equalsIgnoreCase("Leased")){
					v.OwnershipType.clear();
					v.OwnershipType.sendKeys(Parameters.
							OwnerShipType.split("#")[k]);
					Thread.sleep(1000);
					v.OwnershipType.sendKeys(Keys.TAB);
					Thread.sleep(3000);						
					try {
						v.LeasedDate.sendKeys(date1);
						v.LeasedDate.sendKeys(Keys.TAB);
					} catch (Exception e1) {						
					}
					Thread.sleep(1000);
				}else{					
					v.OwnershipType.clear();
					Thread.sleep(1000);	
					v.OwnershipType.sendKeys(Parameters.OwnerShipType.split("#")[k]);
					Thread.sleep(1000);
					v.OwnershipType.sendKeys(Keys.TAB);
					Thread.sleep(1000);
					try {
						if(v.PurchaseDate.isDisplayed()){
							v.PurchaseDate.sendKeys(Parameters.PurchaseDate.split("#")[k]);
						}
					} catch (Exception e1) {
					}
				}
				
				if(Parameters.CV_VehicleType.split("#")[k].toUpperCase().contains("TRAILER")){
					trailler_Vehicle(k);
				}
				
				RM.wait_For_Element(v.TypeOfCommercialUse);
				v.TypeOfCommercialUse.sendKeys(Parameters.CV_TypeOfCommercialUse.split("#")[k]);
				Thread.sleep(1000);
				v.TypeOfCommercialUse.sendKeys(Keys.TAB);
				Thread.sleep(1000);
				RM.wait_For_Element(v.CommoditiesCarried);
				Thread.sleep(1000);
				try{
					if(v.CommoditiesCarried.isDisplayed()){
					v.CommoditiesCarried.sendKeys(Parameters.CV_CommoditiesCarried.split("#")[k].trim());
					v.CommoditiesCarried.sendKeys(Keys.TAB);	
					Thread.sleep(3000);
					}
				}catch(Exception e3){
					
				}
				
				
				v.RadiusOfOperation.sendKeys(Parameters.CV_RadiusOfOperation.split("#")[k]);
				v.ListPriceNew.sendKeys(Parameters.CV_ListPriceNew.split("#")[k]);
				
				
				/******Code added by Naveen********/
				
				Thread.sleep(3000);
				if(!Parameters.MonthsInUS.isEmpty()){					
					Thread.sleep(2000);
					v.RiskCVInput_MonthsInUS.clear();
					Thread.sleep(1000);
					v.RiskCVInput_MonthsInUS.sendKeys(Parameters.MonthsInUS);
					Thread.sleep(1000);
					v.RiskCVInput_MonthsInUS.sendKeys(Keys.TAB);
					Thread.sleep(1000);
				}	
				
	/**********************************************************************************************************/			
				
				
				
				RM.captureScreenShot(docx,run,out);
				((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", v.Save);
				v.Save.click();
				driver.switchTo().defaultContent();
				boolean flag2 = RM.verify_PageTitle(driver, "Vehicle");
				try {
					Assert.assertEquals(flag2, true);
				} catch (AssertionError g) {
					g.printStackTrace();
					System.out.println("Failed to Navigate to Vehicle Screen");
				}
			}catch(Exception laste){
				laste.printStackTrace();
			}
		
	}

	
	public void add_NonOwned_Vehicle(int i, XWPFDocument docx,XWPFRun run,FileOutputStream out) throws InterruptedException{
		
		int j=i;
		
		try {
			RM.wait_For_Element(v.AddVehicle);
			Thread.sleep(2000);
			v.AddVehicle.click();			
			Thread.sleep(2000);
			try{
				driver.switchTo().frame(0);
			}catch(Exception e){				
			}
			
			boolean flag = RM.verify_PageTitle(driver, "Vehicle Lookup Screen");		
			try {
				Assert.assertEquals(flag, true);
			} catch (AssertionError e) {
				e.printStackTrace();
				System.out.println("Failed to Navigate to Vehicle Lookup Screen");
			}
			try{
				if(!v.LookupType_NonOwned.isDisplayed()){
					add_Commercial_Vehicle(j, docx, run, out,55);
					RM.wait_For_Element(v.AddVehicle);
					Thread.sleep(2000);
					v.AddVehicle.click();			
					Thread.sleep(2000);
					try{
						driver.switchTo().frame(0);
					}catch(Exception e){				
					}

				}
				}catch(Exception e){
					add_Commercial_Vehicle(j, docx, run, out,55);
					RM.wait_For_Element(v.AddVehicle);
					Thread.sleep(5000);
					v.AddVehicle.click();			
					Thread.sleep(4000);
					try{
						driver.switchTo().frame(0);
					}catch(Exception e2){				
					}
				}		
			RM.wait_For_Element(v.LookupType_NonOwned);
			v.LookupType_NonOwned.click();
			Thread.sleep(1000);		
			v.NonOwnedInput_Type.sendKeys(Parameters.NonOwnedInput_Type.split("#")[j]);
			v.NonOwnedInput_Type.sendKeys(Keys.TAB);
			Thread.sleep(2000);
			
			if(Parameters.SameUseClassAs.split("#")[j].equalsIgnoreCase("other")){
				v.SameUseClassAs.sendKeys("Other");
				Thread.sleep(1000);
				v.SameUseClassAs.sendKeys(Keys.TAB);
				Thread.sleep(1000);
				v.ExposureDays.sendKeys(Parameters.ExposureDays.split("#")[j]);
				v.ExposureDays.sendKeys(Keys.TAB);
				Thread.sleep(1000);
				v.VehicleType.sendKeys(Parameters.Non_VehicleType.split("#")[j]);
				v.VehicleType.sendKeys(Keys.TAB);
				Thread.sleep(1000);												
				v.Limit.sendKeys(Parameters.Limit.split("#")[j]);
				v.Limit.sendKeys(Keys.TAB);
				Thread.sleep(1000);
				v.Add.click();
				Thread.sleep(3000);		
				
				//Add Non-Owned Light Commercial Vehicle Details
				boolean flag1 = RM.verify_PageTitle(driver, "Commercial Vehicle Details");
				try {
					Assert.assertEquals(flag1, true);
				} catch (AssertionError f) {
					System.out.println("Failed to Navigate to Commercial Vehicle Details Screen");					
				}
				
				
				try{
					if(driver.findElement(By.xpath("//*[@fieldref='RiskTrailerInput.PulledBy']")).isDisplayed()){
					driver.findElement(By.xpath("//*[@fieldref='RiskTrailerInput.PulledBy']")).sendKeys(Parameters.CV_Trailer_PulledBy.split("#")[j]);
					driver.findElement(By.xpath("//*[@fieldref='RiskTrailerInput.PulledBy']")).sendKeys(Keys.TAB);
					if(Parameters.Non_Trailer_PulledBy.toUpperCase().contains("OTHER")){
						driver.findElement(By.xpath("//*[@fieldref='RiskCommercialAutoInput.LocationSearch']")).sendKeys(Parameters.Non_Trailer_LocationOfUse.split("#")[j]);					
						try {
							driver.findElement(By.xpath("//img[@class='g-btn-img-loneIcon']")).click();							
							Thread.sleep(4000);
						} catch (Exception e1) {
						}
						try {
							driver.switchTo().frame(0);
							driver.findElements(By.className("g-btn-text")).get(0).click();
							Thread.sleep(2000);
							
							try {
								driver.switchTo().window(" ");
								driver.switchTo().frame(driver.findElement(By.tagName("iframe")).getAttribute("name"));
							} catch (Exception es) {
								driver.switchTo().frame(driver.findElement(By.tagName("iframe")).getAttribute("name"));
							}												
							
						} catch (Exception e2) {

						}
						v.TypeOfCommercialUse.clear();
						v.TypeOfCommercialUse.sendKeys(Parameters.Non_TypeOfCommercialUse.split("#")[j]);
						v.TypeOfCommercialUse.sendKeys(Keys.TAB);
						Thread.sleep(2000);
						v.CommoditiesCarried.sendKeys(Parameters.Non_CommoditiesCarried.split("#")[j]);
						v.CommoditiesCarried.sendKeys(Keys.TAB);
						Thread.sleep(2000);
						v.RadiusOfOperation.sendKeys(Parameters.Non_RadiusOfOperation.split("#")[j]);
						Thread.sleep(2000);
						RM.captureScreenShot(docx,run,out);
						((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", v.Save);
						v.Save.click();
					}else{					
						driver.findElement(By.xpath("//*[@fieldref='RiskTrailerInput.PulledBy']")).sendKeys(Parameters.CV_Trailer_PulledBy.split("#")[j]);
						driver.findElement(By.xpath("//*[@fieldref='RiskTrailerInput.PulledBy']")).sendKeys(Keys.TAB);
						RM.captureScreenShot(docx,run,out);
						((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", v.Save);
						v.Save.click();
					}
					
					}
				}catch(Exception a){
					
				}				

				try {
					if (driver.findElement(By.xpath("//*[@fieldref='RiskCommercialVehicleInput.VehicleWeight']"))
							.isDisplayed()) {
						driver.findElement(By.xpath("//*[@fieldref='RiskCommercialVehicleInput.VehicleWeight']"))
								.sendKeys(Parameters.Non_VehicleWeight.split("#")[j]);
						driver.findElement(By.xpath("//*[@fieldref='RiskCommercialVehicleInput.VehicleWeight']"))
								.sendKeys(Keys.TAB);
						driver.findElement(By.xpath("//*[@fieldref='RiskCommercialAutoInput.LocationSearch']"))
								.sendKeys(Parameters.Non_Trailer_LocationOfUse.split("#")[j]);
						try {
							driver.findElement(By.xpath("//img[@class='g-btn-img-loneIcon']")).click();
							Thread.sleep(4000);
						} catch (Exception e1) {
						}
						try {
							driver.switchTo().frame(0);
							((JavascriptExecutor) driver).executeScript("arguments[0].style.border='3px solid red'", driver.findElements(By.className("g-btn-text")).get(0));
							driver.findElements(By.className("g-btn-text")).get(0).click();
							Thread.sleep(2000);

							try {
								driver.switchTo().window(" ");
								driver.switchTo().frame(driver.findElement(By.tagName("iframe")).getAttribute("name"));
							} catch (Exception es) {
								driver.switchTo().frame(driver.findElement(By.tagName("iframe")).getAttribute("name"));
							}
							
							v.TypeOfCommercialUse.clear();
							v.TypeOfCommercialUse.sendKeys(Parameters.Non_TypeOfCommercialUse.split("#")[j]);
							v.TypeOfCommercialUse.sendKeys(Keys.TAB);
							Thread.sleep(2000);
							v.CommoditiesCarried.sendKeys(Parameters.Non_CommoditiesCarried.split("#")[j]);
							v.CommoditiesCarried.sendKeys(Keys.TAB);
							Thread.sleep(2000);
							v.RadiusOfOperation.sendKeys(Parameters.Non_RadiusOfOperation.split("#")[j]);
							Thread.sleep(2000);
							RM.captureScreenShot(docx,run,out);
							((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", v.Save);
							v.Save.click();

						} catch (Exception e2) {

						}
					}
				} catch (Exception a) {

				}
				
				

				Thread.sleep(3000);
				boolean flag2 = RM.verify_PageTitle(driver, "Vehicle");
				try {
					Assert.assertEquals(flag2, true);
				} catch (AssertionError g) {
					System.out.println("Failed to Navigate to Vehicle Screen");
				}				
			}else{
				v.NonOwnedInput_Type.sendKeys(Parameters.NonOwnedInput_Type.split("#")[j]);
				v.NonOwnedInput_Type.sendKeys(Keys.TAB);
				v.SameUseClassAs.sendKeys(Parameters.SameUseClassAs.split("#")[j]);
				v.SameUseClassAs.sendKeys(Keys.TAB);
				v.ExposureDays.sendKeys(Parameters.ExposureDays.split("#")[j]);
				v.Limit.sendKeys(Parameters.Limit.split("#")[j]);
				v.VehicleType.sendKeys(Parameters.Non_VehicleType.split("#")[j]);
				v.VehicleType.sendKeys(Keys.TAB);
				Thread.sleep(1000);
				RM.captureScreenShot(docx,run,out);
				v.Add.click();
			}
		} catch (Exception e) {
		System.out.println("Failed to add Non Owned Vehicle");
			e.printStackTrace();
		}
		
	}
	
	
	public String retrive_ValueName(){
		String vehicle="";		
		List <WebElement> ele_Vehicles = driver.findElements(By.xpath("//div[@class='x-panel-body x-panel-body-noheader']//table/tbody/tr/td[1]/div"));
		vehicle = ele_Vehicles.get(ele_Vehicles.size()-1).getText();
		System.out.println("Vehicel Add: "+vehicle);
		return vehicle;
	}
	
	public void trailler_Vehicle(int k) {
		try {
			driver.findElement(By.xpath("//*[@fieldref='RiskTrailerInput.PulledBy']")).clear();
			driver.findElement(By.xpath("//*[@fieldref='RiskTrailerInput.PulledBy']"))
					.sendKeys(Parameters.CV_Trailer_PulledBy.trim());
			Thread.sleep(1000);
			driver.findElement(By.xpath("//*[@fieldref='RiskTrailerInput.PulledBy']")).sendKeys(Keys.TAB);
			Thread.sleep(2000);
			if (Parameters.CV_Trailer_PulledBy.toUpperCase().contains("OTHER")) {
				driver.findElement(By.xpath("//*[@fieldref='RiskCommercialAutoInput.LocationSearch']"))
						.sendKeys(Parameters.CV_Trailer_LocationOfUse.split("#")[k]);

				try {
					driver.findElement(By.xpath("//img[@class='g-btn-img-loneIcon']")).click();
					Thread.sleep(8000);
				} catch (Exception e1) {
				}
				try {
					driver.switchTo().frame(0);
					driver.findElements(By.className("g-btn-text")).get(0).click();
					Thread.sleep(2000);

					try {
						driver.switchTo().window(" ");
						driver.switchTo().frame(driver.findElement(By.tagName("iframe")).getAttribute("name"));
					} catch (Exception es) {
						driver.switchTo().frame(driver.findElement(By.tagName("iframe")).getAttribute("name"));
					}
				} catch (Exception e2) {
				}
			}
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			System.out.println("Failed in Trailler_Vehicle");
		}
	}

}
