package modules;

import java.io.FileOutputStream;
import java.util.List;

import org.apache.poi.xwpf.usermodel.XWPFDocument;
import org.apache.poi.xwpf.usermodel.XWPFRun;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.Assert;

import com.aventstack.extentreports.ExtentTest;

import utils.DataManager;
import utils.Reusable_Methods;

public class Premium {
	WebDriver driver;
	pages.Premium p;
	ExtentTest test;
	String path;
	Reusable_Methods RM;
	JavascriptExecutor js;
	
	
	public Premium(WebDriver webdriver, ExtentTest test1) {
		driver=webdriver;
		
		p=new pages.Premium(driver);		
		path = "\\\\NBFC.COM\\departments\\QA\\Northbridge_QA\\IRCA_ExecutionWorkSpace\\RateTesting_CV_NB\\CV_RateTesting_NB\\TestData\\CV_RateTest_DataSheet_NL.xlsx";
		test = test1;
		RM = new Reusable_Methods(driver);
		js = (JavascriptExecutor) driver;
		
	}
	String BuildingPremium=null;
	public void Premium(int row,XWPFDocument docx,XWPFRun run,FileOutputStream out) throws InterruptedException{		
		try {
							
		

			/*try{
				if(driver.findElement(By.xpath("//*[@class='g-btn-text'][contains(text(),'Approve')]")).isDisplayed()){
					driver.findElement(By.xpath("//*[@class='g-btn-text'][contains(text(),'Approve')]")).click();
					Thread.sleep(2000);
					driver.findElement(By.xpath("//button[text()='Yes']")).click();
					Thread.sleep(6000);
				}
			}catch(Exception e){
				System.out.println("Approve button not displayed");
			}
						*/
			
			
			RM.wait_For_Element(p.Auto);
			((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true)", p.Auto);
			p.Auto.click();
			Thread.sleep(3000);
			
			// VerfiySubmissionPage
			boolean flag = false;
			flag = RM.verify_PageTitle(driver, "Auto Premium");
			try {
				Assert.assertEquals(flag, true);
				test.pass("Sucessfully Navigated to Auto Premium Page");
				System.out.println("Sucessfully Navigated to Auto Premium Page");
			} catch (AssertionError e) {
				System.out.println("Failed to Navigate to Auto Premium page");
			
				test.fail("Failed to Navigate Auto Premium Page");			
			}	
			
//			p.AutoPremium.click();
			List<WebElement> ele = driver.findElements(By.xpath("//div[@class='toggleHeader toggle-collapsed']/div[@class='toggleHeaderInner']"));
			System.out.println(ele.size());
			for(int i = 0;i<ele.size();i++){
				((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true)",
						ele.get(i));
				ele.get(i).click();
				RM.captureScreenShot(docx, run, out);
			}
//			System.out.println(p.Premium_Vehicle.size());
			String calculated_Premeum=null;
			try {
				/*for(int pre=0;pre<=p.Premium_Vehicle.size();pre++){	
					((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true)",
							p.Premium_Vehicle.get(pre));
					p.Premium_Vehicle.get(pre).click();				
				}*/
				capture_CalculatedPremium_Vlaues(row,docx,run,out);
				Thread.sleep(2000);
				RM.captureScreenShot(docx,run,out);
			} catch (Exception e) {

			}
			
			
			
			
					
			p.Back_to_Premium_Summary.click();
			
			/*WebDriverWait wait = new WebDriverWait(driver, 20);
			wait.until(ExpectedConditions.visibilityOf(p.quote_Button));
			Thread.sleep(1000);
			p.quote_Button.click();
			wait.until(ExpectedConditions.visibilityOf(p.bind_Button));
			Thread.sleep(1000);
			try{
				p.bind_Button.click();
				driver.findElement(By.xpath("//button[text()='Yes']")).click();
				wait.until(ExpectedConditions.visibilityOf(p.book_Button));
				Thread.sleep(1000);
				p.book_Button.click();
			}catch(Exception bind){
				System.out.println("Failed to Bind");
			}	
			
			js.executeScript("window.scrollBy(0,1500)");
			driver.findElement(By.xpath("//*[@class='g-btn-text'][contains(text(),'Next')]")).click();
			Thread.sleep(3000);*/
		} catch (Exception e) {
			System.out.println("Failed to Add Premium Details");
		}
	}				

	public void capture_CalculatedPremium_Vlaues(int row, XWPFDocument docx, XWPFRun run, FileOutputStream out) {
		try {
			String str;
			try {
				str = "";
				for (int i = 0; i < p.CovTPLBodilyInjuryOutput.size(); i++) {
					((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true)",
							p.CovTPLBodilyInjuryOutput.get(i));
					try {
						str = str + p.CovTPLBodilyInjuryOutput.get(i).getText() + "#";
					} catch (Exception e) {
						System.out.println("Failed to Capture CovTPLBodilyInjuryOutput");
						str = str + "Value not captured" + "#";
					}
				}
				str = str.substring(0, str.length()-1);
				System.out.println(str);
				DataManager.writeData(path, row, 11, str, "PremiumValidation");
			} catch (Exception e10) {
				// TODO Auto-generated catch block
				
			}

			try {
				str = "";

				for (int i = 0; i < p.CovTPLDirectCompensationOutput.size(); i++) {
					try {
						((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true)",
								p.CovTPLDirectCompensationOutput.get(i));
						str = str + p.CovTPLDirectCompensationOutput.get(i).getText() + "#";
					} catch (Exception e) {
						System.out.println("Failed to Capture CovTPLDirectCompensationOutput");
						str = str + "Value not captured" + "#";
					}
				}
				str = str.substring(0, str.length()-1);
				System.out.println(str);

				DataManager.writeData(path, row, 13, str, "PremiumValidation");
			} catch (Exception e9) {
				// TODO Auto-generated catch block
				
			}

			try {
				str = "";
				for (int i = 0; i < p.CovTPLPropertyDamageOutput.size(); i++) {
					try {
						((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true)",
								p.CovTPLPropertyDamageOutput.get(i));
						str = str+p.CovTPLPropertyDamageOutput.get(i).getText() + "#";
					} catch (Exception e) {
						System.out.println("Failed to Capture CovTPLPropertyDamageOutput");
						str = str + "Value not captured" + "#";
					}
				}
				str = str.substring(0, str.length()-1);
				System.out.println(str);
				DataManager.writeData(path, row, 12, str, "PremiumValidation");
			} catch (Exception e8) {
				// TODO Auto-generated catch block
				
			}

			try {
				str = "";
				for (int i = 0; i < p.CovAccidentBenefitsOutput.size(); i++) {
					try {
						((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true)",
								p.CovAccidentBenefitsOutput.get(i));
						str = str+p.CovAccidentBenefitsOutput.get(i).getText() + "#";
					} catch (Exception e) {
						System.out.println("Failed to Capture CovAccidentBenefitsOutput");
						str = str + "Value not captured" + "#";
					}
				}
				str = str.substring(0, str.length()-1);
				System.out.println(str);
				DataManager.writeData(path, row, 14, str, "PremiumValidation");
			} catch (Exception e7) {
				// TODO Auto-generated catch block
				
			}
			RM.captureScreenShot(docx, run, out);

			try {
				str = "";
				for (int i = 0; i < p.CovUninsuredAutomobileOutput.size(); i++) {
					try {
						((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true)",
								p.CovAccidentBenefitsOutput.get(i));
						str = str+p.CovUninsuredAutomobileOutput.get(i).getText() + "#";
					} catch (Exception e) {
						System.out.println("Failed to Capture CovUninsuredAutomobileOutput");
						str = str + "Value not captured" + "#";
					}
				}
				str = str.substring(0, str.length()-1);
				System.out.println(str);
				DataManager.writeData(path, row, 15, str, "PremiumValidation");
			} catch (Exception e6) {
				// TODO Auto-generated catch block
			
			}

			try {
				str = "";
				for (int i = 0; i < p.CovComprehensiveOutput.size(); i++) {
					try {
						((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true)",
								p.CovComprehensiveOutput.get(i));
						str = str+p.CovComprehensiveOutput.get(i).getText() + "#";
					} catch (Exception e) {
						System.out.println("Failed to Capture CovComprehensiveOutput");
						str = str + "Value not captured" + "#";
					}
				}
				str = str.substring(0, str.length()-1);
				System.out.println(str);
				DataManager.writeData(path, row, 17, str, "PremiumValidation");
			} catch (Exception e5) {
				// TODO Auto-generated catch block
				
			}

			try {
				str = "";
				for (int i = 0; i < p.CovCollisionOutput.size(); i++) {
					try {
						((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true)",
								p.CovCollisionOutput.get(i));
						str = str+p.CovCollisionOutput.get(i).getText() + "#";
					} catch (Exception e) {
						System.out.println("Failed to Capture CovCollisionOutput");
						str = str + "Value not captured" + "#";
					}
				}
				str = str.substring(0, str.length()-1);
				System.out.println(str);
				DataManager.writeData(path, row, 16, str, "PremiumValidation");
			} catch (Exception e4) {
				// TODO Auto-generated catch block
			
			}

			try {
				str = "";

				for (int i = 0; i < p.Cov44FamilyProtectionOutput.size(); i++) {
					try {
						((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true)",p.Cov44FamilyProtectionOutput.get(i));
						str = str+p.Cov44FamilyProtectionOutput.get(i).getText() + "#";
					} catch (Exception e) {
						System.out.println("Failed to Capture Cov44FamilyProtectionOutput");
						str = str + "Value not captured" + "#";
					}
				}
				str = str.substring(0, str.length()-1);
				System.out.println(str);
				DataManager.writeData(path, row, 18, str, "PremiumValidation");
			} catch (Exception e3) {
				// TODO Auto-generated catch block
			
			}
			
			try {
				str = "";

				for (int i = 0; i < p.Cov44FamilyProtectionOutput.size(); i++) {
					try {
						((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true)",p.Cov44FamilyProtectionOutput.get(i));
						str = str+p.Cov44FamilyProtectionOutput.get(i).getText() + "#";
					} catch (Exception e) {
						System.out.println("Failed to Capture Cov44FamilyProtectionOutput");
						str = str + "Value not captured" + "#";
					}
				}
				str = str.substring(0, str.length()-1);
				System.out.println(str);
				DataManager.writeData(path, row, 18, str, "PremiumValidation");
			} catch (Exception e2) {
				// TODO Auto-generated catch block
			
			}
			
			try {
				str = "";

				for (int i = 0; i < p.CovAllPerilsOutput.size(); i++) {
					try {
						((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true)",p.CovAllPerilsOutput.get(i));
						str = str+p.CovAllPerilsOutput.get(i).getText() + "#";
					} catch (Exception e) {
						System.out.println("Failed to Capture CovAllPerilsOutput");
						str = str + "Value not captured" + "#";
					}
				}
				str = str.substring(0, str.length()-1);
				System.out.println(str);
				DataManager.writeData(path, row, 19, str, "PremiumValidation");
			} catch (Exception e1) {
				// TODO Auto-generated catch block
				
			}
			
			try {
				str = "";
				for (int i = 0; i < p.CovSpecifiedPerilsOutput.size(); i++) {
					try {
						((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true)",p.CovSpecifiedPerilsOutput.get(i));
						str = str+p.CovSpecifiedPerilsOutput.get(i).getText() + "#";
					} catch (Exception e) {
						System.out.println("Failed to Capture CovSpecifiedPerilsOutput");
						str = str + "Value not captured" + "#";
					}
				}
				str = str.substring(0, str.length()-1);
				System.out.println(str);
				DataManager.writeData(path, row, 20, str, "PremiumValidation");
			} catch (Exception e) {
				// TODO Auto-generated catch block
				
			}

		} catch (Exception e) {
			System.out.println("Failed to capture the premium");
		}
	}

}
