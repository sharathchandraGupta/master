package modules;

import java.io.FileOutputStream;
import java.util.List;

import org.apache.poi.xwpf.usermodel.XWPFDocument;
import org.apache.poi.xwpf.usermodel.XWPFRun;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.Assert;

import utils.Parameters;
import utils.Reusable_Methods;

public class Coverage {
	WebDriver driver;
	pages.Coverage cov;
	Reusable_Methods RM;

	public Coverage(WebDriver webdriver) {
		driver = webdriver;
		cov = new pages.Coverage(driver);
		RM = new Reusable_Methods(driver);

	}

	
	public void Coverage_New(XWPFDocument docx,XWPFRun run,FileOutputStream out) throws InterruptedException {
		int cover_Coll_ind = 0;
		int cover_Comp_ind = 0;
		int cover_Speci_ind=0;
		try{
			try {
				cov.CoverageTab.click();
				RM.wait_For_Element("//*[text()='AUTO']");
				Thread.sleep(2000); 				
				boolean flag = RM.verify_PageTitle(driver, "Coverage"); Assert.assertEquals(flag, true);
			} catch (Exception e) {
				System.out.println("Failed to Navigate to Coverage Page");				
			}			
			RM.captureScreenShot(docx,run,out);
			
			// To Click on Auto
			driver.findElement(By.xpath("//*[text()='AUTO']")).click();
			RM.captureScreenShot(docx,run,out);
			//To update the values of policy level endorsements
			
		}catch(Exception e1){
			System.out.println("Failed to click on Auto Tab");
		}

		// To find the no of vehicles and click on each vehicle
		try {
			List<WebElement> ele_Vechicle = null;
		
			
			try{
				ele_Vechicle = driver.findElements(
						By.xpath("//*[text()='AUTO']/parent::div/following-sibling::div/div/child::div[3]/table/tbody/tr/td[2]/div[1]/div"));
				//
			}catch(Exception e){
				ele_Vechicle = driver.findElements(
						By.xpath("//*[text()='AUTO']/parent::div/following-sibling::div/div/child::div[13]/table/tbody/tr/td[2]/div[1]/div"));
			}
			/*if(!Parameters.CV_VehicleType.split("#")[0].trim().toUpperCase().contains("TRAILER")){				
				 ele_Vechicle = driver.findElements(
						By.xpath("//*[text()='AUTO']/parent::div/following-sibling::div/div/child::div[3]/table/tbody/tr/td[2]/div[1]/div"));
			}else{
				ele_Vechicle = driver.findElements(
						By.xpath("//*[text()='AUTO']/parent::div/following-sibling::div/div/div[3]/table/tbody/tr/td[2]/div[1]"));	
			}*/
			
			for (int i = 0; i < ele_Vechicle.size(); i++) {
				
				//To click on vehicles (get the no of vehicles and click on it one by one)
				List<WebElement> ele = null;
				try{
					ele = driver.findElements(
							By.xpath("//*[text()='AUTO']/parent::div/following-sibling::div/div/child::div[3]/table/tbody/tr/td[2]/div[1]/div"));
					//
				}catch(Exception e){
					ele = driver.findElements(
							By.xpath("//*[text()='AUTO']/parent::div/following-sibling::div/div/child::div[13]/table/tbody/tr/td[2]/div[1]/div"));
				}
				/*if(!Parameters.CV_VehicleType.split("#")[0].trim().toUpperCase().contains("TRAILER")){
					ele = driver.findElements(By.xpath("//*[text()='AUTO']/parent::div/following-sibling::div/div/child::div[3]/table/tbody/tr/td[2]/div[1]/div"));
				}else{
					ele = driver.findElements(By.xpath("//*[text()='AUTO']/parent::div/following-sibling::div/div/div[13]/table/tbody/tr/td[2]/div[1]"));
				}*/
				 				
				try{
					((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true)", ele.get(i));
					RM.captureScreenShot(docx,run,out);
					ele.get(i).click();
					
					if(Parameters.Cover_TPL_BodilyInjury_Flag.split("#")[i].equalsIgnoreCase("yes")){
						if(!cov.CovTPLBodilyInjuryCheckBox.get(i).isSelected()){
							cov.CovTPLBodilyInjuryCheckBox.get(i).click();
						}
						RM.wait_For_Element(cov.CovTPLBodilyInjuryInput.get(i));
						try {
							cov.CovTPLBodilyInjuryInput.get(i).clear();
							Thread.sleep(2000);
						} catch (Exception e) {
						}
						cov.CovTPLBodilyInjuryInput.get(i).sendKeys(Parameters.Cover_TPL_BodilyInjury_Value.split("#")[i]);
						cov.CovTPLBodilyInjuryInput.get(i).sendKeys(Keys.TAB);
						Thread.sleep(2000);
					}else if(Parameters.Cover_TPL_BodilyInjury_Flag.split("#")[i].equalsIgnoreCase("No")){
						if(cov.CovTPLBodilyInjuryCheckBox.get(i).isSelected()){
							cov.CovTPLBodilyInjuryCheckBox.get(i).click();
						}
					}
					
					if(Parameters.Cover_DirectCompensation_Flag.split("#")[i].equalsIgnoreCase("Yes")){
						if(!cov.CovTPLDirectCompensation_CheckBox.get(i).isSelected()){
							cov.CovTPLDirectCompensation_CheckBox.get(i).click();
						}
						RM.wait_For_Element(cov.CovComprehensiveInput_Indicator.get(i));
						try {
							cov.CovTPLDirectCompensation_Deductible.get(i).clear();
						} catch (Exception e) {
						}
						cov.CovTPLDirectCompensation_Deductible.get(i).sendKeys(Parameters.Cover_DirectCompensation_Value.split("#")[i]);
						cov.CovTPLDirectCompensation_Deductible.get(i).sendKeys(Keys.TAB);
						Thread.sleep(2000);
					}else if(Parameters.Cover_DirectCompensation_Flag.split("#")[i].equalsIgnoreCase("No")){
						if(cov.CovTPLDirectCompensation_CheckBox.get(i).isSelected()){
							cov.CovTPLDirectCompensation_CheckBox.get(i).click();
						}
					}
					RM.captureScreenShot(docx,run,out);
					
					
				}catch(Exception e4){
					
				}
				
				
				try{
					((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true)", cov.CovAllPerilsInput_Indicator.get(i));
					
					//To un check CovAllPerilsInput
					if(Parameters.Cover_AllPerals_Flag.split("#")[i].equalsIgnoreCase("Yes")){
						if(!cov.CovAllPerilsInput_Indicator.get(i).isSelected()){
							cov.CovAllPerilsInput_Indicator.get(i).click();
						}
						
						try {
							cov.CovAllPerilsInput_Deductible.get(i).clear();
						} catch (Exception e) {
						}
						cov.CovAllPerilsInput_Deductible.get(i).sendKeys(Parameters.Cover_AllPerals_Value.split("#")[i]);
						cov.CovAllPerilsInput_Deductible.get(i).sendKeys(Keys.TAB);
						Thread.sleep(2000);
					}else if(Parameters.Cover_AllPerals_Flag.split("#")[i].equalsIgnoreCase("No")){
						if(cov.CovAllPerilsInput_Indicator.get(i).isSelected()){
							cov.CovAllPerilsInput_Indicator.get(i).click();
						}
					}					
					Thread.sleep(3000);
									
					
					//To  check CovCollisionInput_Indicator and enter Cover_Collision
					((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true)", cov.CovCollisionInput_Indicator.get(i));
					if(Parameters.Cover_Collision_Flag.split("#")[i].equalsIgnoreCase("yes")){						
						if(!cov.CovCollisionInput_Indicator.get(i).isSelected()){
							cov.CovCollisionInput_Indicator.get(i).click();
							Thread.sleep(2000);
						}
						RM.wait_For_Element(cov.CovCollisionInput_Deductible.get(cover_Coll_ind));
						Thread.sleep(2000);
						try {
							cov.CovCollisionInput_Deductible.get(cover_Coll_ind).clear();
						} catch (Exception e) {
						}						
						cov.CovCollisionInput_Deductible.get(cover_Coll_ind).sendKeys(Parameters.Cover_Collision_Value.split("#")[i]);
						cov.CovCollisionInput_Deductible.get(cover_Coll_ind).sendKeys(Keys.TAB);
						cover_Coll_ind = cover_Coll_ind+1;	
					}else if(Parameters.Cover_Collision_Flag.split("#")[i].equalsIgnoreCase("No")){
						if(cov.CovCollisionInput_Indicator.get(i).isSelected()){
							cov.CovCollisionInput_Indicator.get(i).click();	
							Thread.sleep(2000);
						}
					}
					
					Thread.sleep(3000);
			
					//To Check CovComprehensiveInput_Indicator and enter Cover_Comprehensive calue
					((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true)", cov.CovComprehensiveInput_Indicator.get(i));
					if(Parameters.Cover_Comprehensive_Flag.split("#")[i].equalsIgnoreCase("Yes")){
						if(!cov.CovComprehensiveInput_Indicator.get(i).isSelected()){
							cov.CovComprehensiveInput_Indicator.get(i).click();
							Thread.sleep(2000);
						}
						RM.wait_For_Element(cov.CovComprehensiveInput_Deductible.get(cover_Comp_ind));
						Thread.sleep(2000);
						cov.CovComprehensiveInput_Deductible.get(cover_Comp_ind).clear();
						cov.CovComprehensiveInput_Deductible.get(cover_Comp_ind).sendKeys(Parameters.Cover_Comprehensive_Value.split("#")[i]);
						cov.CovComprehensiveInput_Deductible.get(cover_Comp_ind).sendKeys(Keys.TAB);
						cover_Comp_ind =cover_Comp_ind+1;
					}else if(Parameters.Cover_Comprehensive_Flag.split("#")[i].equalsIgnoreCase("No")){
						if(cov.CovComprehensiveInput_Indicator.get(i).isSelected()){
							cov.CovComprehensiveInput_Indicator.get(i).click();	
							Thread.sleep(2000);
						}
					}
					
					
					//To Check CovSpecifiedPerilsInput.Indicator and enter Cover_Special Peril value
					((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true)", cov.CovSpecifiedPerilsInput_CheckBox.get(i));
					if(Parameters.Cover_SpecifiedPerils_Flag.split("#")[i].equalsIgnoreCase("Yes")){
						if(!cov.CovSpecifiedPerilsInput_CheckBox.get(i).isSelected()){
							cov.CovSpecifiedPerilsInput_CheckBox.get(i).click();
							Thread.sleep(2000);
						}
						RM.wait_For_Element(cov.CovSpecifiedPerilsInput_Deductible.get(cover_Speci_ind));
						Thread.sleep(2000);
						try {
							cov.CovSpecifiedPerilsInput_Deductible.get(cover_Speci_ind).clear();
						} catch (Exception e) {
						}
						cov.CovSpecifiedPerilsInput_Deductible.get(cover_Speci_ind).sendKeys(Parameters.Cover_SpecifiedPerils_Value.split("#")[i]);
						cov.CovSpecifiedPerilsInput_Deductible.get(cover_Speci_ind).sendKeys(Keys.TAB);
						cover_Speci_ind = cover_Speci_ind+1;
					}else if(Parameters.Cover_Comprehensive_Flag.split("#")[i].equalsIgnoreCase("No")){
						if(cov.CovSpecifiedPerilsInput_CheckBox.get(i).isSelected()){
							cov.CovSpecifiedPerilsInput_CheckBox.get(i).click();	
							Thread.sleep(2000);
						}
					}
					
					RM.captureScreenShot(docx,run,out);
				}catch(Exception e5){
					System.out.println("Failed to in Vechicle Physical Damage");
				}
								
				
				
				((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true)", cov.Endorsements.get(i));				
					cov.Endorsements.get(i).click();
					
				/*	try{
						((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true)", cov.Cov20LossOfUseEndInput_Indicator.get(i));
						if (Parameters.Cover_20_Lossof_UseEndt_Flag.equalsIgnoreCase("Yes")) {
							if (!cov.Cov20LossOfUseEndInput_Indicator.get(i).isSelected()) {
								cov.Cov20LossOfUseEndInput_Indicator.get(i).click();
							}
						}else if(Parameters.Cover_20_Lossof_UseEndt_Flag.equalsIgnoreCase("No")){
							if (cov.Cov20LossOfUseEndInput_Indicator.get(i).isSelected()) {
								cov.Cov20LossOfUseEndInput_Indicator.get(i).click();
							}
						}
					}catch(Exception e){
						System.out.println("Failed to Update Endorsements");
					}*/
					
					
				//To select_Coverage_Endorsements				
				if (Parameters.Cover_Endorsements_Select_Flag.split("#")[i].equalsIgnoreCase("YES")){
					//Call method to select the check boxes
					for (int x = 0; x < Parameters.Cover_Endorsment_Coverages_ToSelect.split("_")[i].split("#").length; x++) {
						select_Coverage_Endorsements(Parameters.Cover_Endorsment_Coverages_ToSelect.split("_")[i].split("#")[x],i);
						Thread.sleep(2000);
					} 
				}
				
				//To UnSelect_Coverage_Endorsements			
				if (Parameters.Cover_Endorsements_UnSelect_Flag.split("#")[i].equalsIgnoreCase("YES")){
					//Call method to select the check boxes
					for (int y = 0; y < Parameters.Cover_Endorsment_Coverages_ToUnSelect.split("_")[i].split("#").length; y++) {
						unSelect_Coverage_Endorsements(Parameters.Cover_Endorsment_Coverages_ToUnSelect.split("_")[i].split("#")[y],i);
						Thread.sleep(2000);
					} 
				}
				
				RM.captureScreenShot(docx,run,out);
				Thread.sleep(2000);
				((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true)", driver.findElements(By.xpath("//*[text()='Additional Endorsements']")).get(i));
				driver.findElements(By.xpath("//*[text()='Additional Endorsements']")).get(i).click();				
				Thread.sleep(1000);
				
				if (Parameters.Additional_Endorsment_Coverages_Flag.equalsIgnoreCase("YES")){
					//Call method to select the check boxes
					for (int a = 0; a < Parameters.Additional_Endorsment_Coverages.split("#").length; a++) {
						select_Checkbox_AdditionEndorsement(Parameters.Additional_Endorsment_Coverages.split("#")[a],
								i);
						Thread.sleep(2000);
					} 
				}				
			}		
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("Failed in Vehicle");
			System.out.println(e.getClass());
		}	
		
		policy_Level_Endorsements(docx,run,out);
		
		try{
		JavascriptExecutor js = (JavascriptExecutor) driver;
		//js.executeScript("window.scrollBy(0,1500)");
		((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true)", cov.Next);
		cov.Next.click();
		Thread.sleep(5000);
	} catch (Exception e) {
		System.out.println("Failed to Add Premium Details");
		e.printStackTrace();
	}
	}
	

	
	public void non_Owned_Coverage_New(XWPFDocument docx,XWPFRun run,FileOutputStream out) throws InterruptedException {
		int cover_Coll_ind = 0;
		int cover_Comp_ind = 0;
		int cover_Speci_ind=0;
		try{
			try {
				cov.CoverageTab.click();
				RM.wait_For_Element("//*[text()='AUTO']");
				Thread.sleep(2000); 				
				boolean flag = RM.verify_PageTitle(driver, "Coverage"); Assert.assertEquals(flag, true);
			} catch (Exception e) {
				System.out.println("Failed to Navigate to Coverage Page");				
			}			
			RM.captureScreenShot(docx,run,out);
			
			// To Click on Auto
			driver.findElement(By.xpath("//*[text()='AUTO']")).click();
			RM.captureScreenShot(docx,run,out);
			//To update the values of policy level endorsements
			
		}catch(Exception e1){
			System.out.println("Failed to click on Auto Tab");
		}

		// To find the no of vehicles and click on each vehicle
		try {
			List<WebElement> ele_Vechicle = null;
			List<WebElement> ele_Vech = null;
			
			if(Parameters.Non_VehicleType.split("#")[0].trim().toUpperCase().contains("TRAILER")){				
				 ele_Vechicle = driver.findElements(
						By.xpath("//*[text()='AUTO']/parent::div/following-sibling::div/div/child::div[3]/table/tbody/tr/td[2]/div[1]/div"));
			}else{
				ele_Vech = driver.findElements(
						By.xpath("//*[text()='AUTO']/parent::div/following-sibling::div/div/div"));
				int size = ele_Vech.size();
				if(ele_Vech.size()==3)
				{
					ele_Vechicle = driver.findElements(
							By.xpath("//*[text()='AUTO']/parent::div/following-sibling::div/div/div[2]/table/tbody/tr/td[2]/div[1]"));
					
				}else{
					size =size-1;
					ele_Vechicle = driver.findElements(
							By.xpath("//*[text()='AUTO']/parent::div/following-sibling::div/div/div["+size+"]/table/tbody/tr/td[2]/div[1]"));
				}
				}
			
			for (int i = 0; i < ele_Vechicle.size(); i++) {
				
				//To click on vehicles (get the no of vehicles and click on it one by one)
				List<WebElement> ele = null;
				if(Parameters.Non_VehicleType.split("#")[0].trim().toUpperCase().contains("TRAILER")){
					ele = driver.findElements(By.xpath("//*[text()='AUTO']/parent::div/following-sibling::div/div/child::div[3]/table/tbody/tr/td[2]/div[1]/div"));
				}else{
					ele_Vech = driver.findElements(
							By.xpath("//*[text()='AUTO']/parent::div/following-sibling::div/div/div"));
					
					ele_Vechicle = ele_Vech.get(ele_Vech.size()-1).findElements(By.xpath("/table/tbody/tr/td[2]"));
//					ele = driver.findElements(By.xpath("//*[text()='AUTO']/parent::div/following-sibling::div/div/div[4]/table/tbody/tr/td[2]/div[1]"));
				}
				 				
				try{
					((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true)", ele.get(i));
					RM.captureScreenShot(docx,run,out);
					ele.get(i).click();
					
					if(Parameters.Cover_TPL_BodilyInjury_Flag.split("#")[i].equalsIgnoreCase("yes")){
						if(!cov.CovTPLBodilyInjuryCheckBox.get(i).isSelected()){
							cov.CovTPLBodilyInjuryCheckBox.get(i).click();
						}
						RM.wait_For_Element(cov.CovTPLBodilyInjuryInput.get(i));
						try {
							cov.CovTPLBodilyInjuryInput.get(i).clear();
						} catch (Exception e) {
						}
						cov.CovTPLBodilyInjuryInput.get(i).sendKeys(Parameters.Cover_TPL_BodilyInjury_Value.split("#")[i]);
						cov.CovTPLBodilyInjuryInput.get(i).sendKeys(Keys.TAB);
						Thread.sleep(2000);
					}else if(Parameters.Cover_TPL_BodilyInjury_Flag.split("#")[i].equalsIgnoreCase("No")){
						if(cov.CovTPLBodilyInjuryCheckBox.get(i).isSelected()){
							cov.CovTPLBodilyInjuryCheckBox.get(i).click();
						}
					}
					
					if(Parameters.Cover_DirectCompensation_Flag.split("#")[i].equalsIgnoreCase("Yes")){
						if(!cov.CovTPLDirectCompensation_CheckBox.get(i).isSelected()){
							cov.CovTPLDirectCompensation_CheckBox.get(i).click();
						}
						RM.wait_For_Element(cov.CovComprehensiveInput_Indicator.get(i));
						try {
							cov.CovTPLDirectCompensation_Deductible.get(i).clear();
						} catch (Exception e) {
						}
						cov.CovTPLDirectCompensation_Deductible.get(i).sendKeys(Parameters.Cover_DirectCompensation_Value.split("#")[i]);
						cov.CovTPLDirectCompensation_Deductible.get(i).sendKeys(Keys.TAB);
						Thread.sleep(2000);
					}else if(Parameters.Cover_DirectCompensation_Flag.split("#")[i].equalsIgnoreCase("No")){
						if(cov.CovTPLDirectCompensation_CheckBox.get(i).isSelected()){
							cov.CovTPLDirectCompensation_CheckBox.get(i).click();
						}
					}
					RM.captureScreenShot(docx,run,out);
					
					
				}catch(Exception e4){
					
				}
				
				
				try{
					((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true)", cov.CovAllPerilsInput_Indicator.get(i));
					
					//To un check CovAllPerilsInput
					if(Parameters.Cover_AllPerals_Flag.split("#")[i].equalsIgnoreCase("Yes")){
						if(!cov.CovAllPerilsInput_Indicator.get(i).isSelected()){
							cov.CovAllPerilsInput_Indicator.get(i).click();
						}
						
						try {
							cov.CovAllPerilsInput_Deductible.get(i).clear();
						} catch (Exception e) {
						}
						cov.CovAllPerilsInput_Deductible.get(i).sendKeys(Parameters.Cover_AllPerals_Value.split("#")[i]);
						cov.CovAllPerilsInput_Deductible.get(i).sendKeys(Keys.TAB);
						Thread.sleep(2000);
					}else if(Parameters.Cover_AllPerals_Flag.split("#")[i].equalsIgnoreCase("No")){
						if(cov.CovAllPerilsInput_Indicator.get(i).isSelected()){
							cov.CovAllPerilsInput_Indicator.get(i).click();
						}
					}					
					Thread.sleep(3000);
									
					
					//To  check CovCollisionInput_Indicator and enter Cover_Collision
					((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true)", cov.CovCollisionInput_Indicator.get(i));
					if(Parameters.Cover_Collision_Flag.split("#")[i].equalsIgnoreCase("yes")){						
						if(!cov.CovCollisionInput_Indicator.get(i).isSelected()){
							cov.CovCollisionInput_Indicator.get(i).click();
							Thread.sleep(2000);
						}
						RM.wait_For_Element(cov.CovCollisionInput_Deductible.get(cover_Coll_ind));
						Thread.sleep(2000);
						try {
							cov.CovCollisionInput_Deductible.get(cover_Coll_ind).clear();
						} catch (Exception e) {
						}						
						cov.CovCollisionInput_Deductible.get(cover_Coll_ind).sendKeys(Parameters.Cover_Collision_Value.split("#")[i]);
						cov.CovCollisionInput_Deductible.get(cover_Coll_ind).sendKeys(Keys.TAB);
						cover_Coll_ind = cover_Coll_ind+1;	
					}else if(Parameters.Cover_Collision_Flag.split("#")[i].equalsIgnoreCase("No")){
						if(cov.CovCollisionInput_Indicator.get(i).isSelected()){
							cov.CovCollisionInput_Indicator.get(i).click();	
							Thread.sleep(2000);
						}
					}
					
					Thread.sleep(3000);
			
					//To Check CovComprehensiveInput_Indicator and enter Cover_Comprehensive calue
					((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true)", cov.CovComprehensiveInput_Indicator.get(i));
					if(Parameters.Cover_Comprehensive_Flag.split("#")[i].equalsIgnoreCase("Yes")){
						if(!cov.CovComprehensiveInput_Indicator.get(i).isSelected()){
							cov.CovComprehensiveInput_Indicator.get(i).click();
							Thread.sleep(2000);
						}
						RM.wait_For_Element(cov.CovComprehensiveInput_Deductible.get(cover_Comp_ind));
						Thread.sleep(2000);
						cov.CovComprehensiveInput_Deductible.get(cover_Comp_ind).clear();
						cov.CovComprehensiveInput_Deductible.get(cover_Comp_ind).sendKeys(Parameters.Cover_Comprehensive_Value.split("#")[i]);
						cov.CovComprehensiveInput_Deductible.get(cover_Comp_ind).sendKeys(Keys.TAB);
						cover_Comp_ind =cover_Comp_ind+1;
					}else if(Parameters.Cover_Comprehensive_Flag.split("#")[i].equalsIgnoreCase("No")){
						if(cov.CovComprehensiveInput_Indicator.get(i).isSelected()){
							cov.CovComprehensiveInput_Indicator.get(i).click();	
							Thread.sleep(2000);
						}
					}
					
					
					//To Check CovSpecifiedPerilsInput.Indicator and enter Cover_Special Peril value
					((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true)", cov.CovSpecifiedPerilsInput_CheckBox.get(i));
					if(Parameters.Cover_SpecifiedPerils_Flag.split("#")[i].equalsIgnoreCase("Yes")){
						if(!cov.CovSpecifiedPerilsInput_CheckBox.get(i).isSelected()){
							cov.CovSpecifiedPerilsInput_CheckBox.get(i).click();
							Thread.sleep(2000);
						}
						RM.wait_For_Element(cov.CovSpecifiedPerilsInput_Deductible.get(cover_Speci_ind));
						Thread.sleep(2000);
						try {
							cov.CovSpecifiedPerilsInput_Deductible.get(cover_Speci_ind).clear();
						} catch (Exception e) {
						}
						cov.CovSpecifiedPerilsInput_Deductible.get(cover_Speci_ind).sendKeys(Parameters.Cover_SpecifiedPerils_Value.split("#")[i]);
						cov.CovSpecifiedPerilsInput_Deductible.get(cover_Speci_ind).sendKeys(Keys.TAB);
						cover_Speci_ind = cover_Speci_ind+1;
					}else if(Parameters.Cover_Comprehensive_Flag.split("#")[i].equalsIgnoreCase("No")){
						if(cov.CovSpecifiedPerilsInput_CheckBox.get(i).isSelected()){
							cov.CovSpecifiedPerilsInput_CheckBox.get(i).click();	
							Thread.sleep(2000);
						}
					}
					
					RM.captureScreenShot(docx,run,out);
				}catch(Exception e5){
					System.out.println("Failed to in Vechicle Physical Damage");
				}
								
				
				
				((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true)", cov.Endorsements.get(i));				
					cov.Endorsements.get(i).click();
					
				/*	try{
						((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true)", cov.Cov20LossOfUseEndInput_Indicator.get(i));
						if (Parameters.Cover_20_Lossof_UseEndt_Flag.equalsIgnoreCase("Yes")) {
							if (!cov.Cov20LossOfUseEndInput_Indicator.get(i).isSelected()) {
								cov.Cov20LossOfUseEndInput_Indicator.get(i).click();
							}
						}else if(Parameters.Cover_20_Lossof_UseEndt_Flag.equalsIgnoreCase("No")){
							if (cov.Cov20LossOfUseEndInput_Indicator.get(i).isSelected()) {
								cov.Cov20LossOfUseEndInput_Indicator.get(i).click();
							}
						}
					}catch(Exception e){
						System.out.println("Failed to Update Endorsements");
					}*/
					
					
				//To select_Coverage_Endorsements				
				if (Parameters.Cover_Endorsements_Select_Flag.split("#")[i].equalsIgnoreCase("YES")){
					//Call method to select the check boxes
					for (int x = 0; x < Parameters.Cover_Endorsment_Coverages_ToSelect.split("_")[i].split("#").length; x++) {
						select_Coverage_Endorsements(Parameters.Cover_Endorsment_Coverages_ToSelect.split("_")[i].split("#")[x],i);
						Thread.sleep(2000);
					} 
				}
				
				//To UnSelect_Coverage_Endorsements			
				if (Parameters.Cover_Endorsements_UnSelect_Flag.split("#")[i].equalsIgnoreCase("YES")){
					//Call method to select the check boxes
					for (int y = 0; y < Parameters.Cover_Endorsment_Coverages_ToUnSelect.split("_")[i].split("#").length; y++) {
						unSelect_Coverage_Endorsements(Parameters.Cover_Endorsment_Coverages_ToUnSelect.split("_")[i].split("#")[y],i);
						Thread.sleep(2000);
					} 
				}
				
				RM.captureScreenShot(docx,run,out);
				Thread.sleep(2000);
				((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true)", driver.findElements(By.xpath("//*[text()='Additional Endorsements']")).get(i));
				driver.findElements(By.xpath("//*[text()='Additional Endorsements']")).get(i).click();				
				Thread.sleep(1000);
				
				if (Parameters.Additional_Endorsment_Coverages_Flag.equalsIgnoreCase("YES")){
					//Call method to select the check boxes
					for (int a = 0; a < Parameters.Additional_Endorsment_Coverages.split("#").length; a++) {
						select_Checkbox_AdditionEndorsement(Parameters.Additional_Endorsment_Coverages.split("#")[a],
								i);
						Thread.sleep(2000);
					} 
				}				
			}		
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("Failed in Vehicle");
			System.out.println(e.getClass());
		}	
		
		policy_Level_Endorsements(docx,run,out);
		
		try{
		JavascriptExecutor js = (JavascriptExecutor) driver;
		//js.executeScript("window.scrollBy(0,1500)");
		((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true)", cov.Next);
		cov.Next.click();
		Thread.sleep(5000);
	} catch (Exception e) {
		System.out.println("Failed to Add Premium Details");
		e.printStackTrace();
	}
	}
	

	public void select_Checkbox_AdditionEndorsement(String str, int ind){
		try{
			switch (str) {
			case "4A":
				((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true)", cov.Cov4AExplosivePermission);
				cov.Cov4AExplosivePermission.click();
				Thread.sleep(1000);
				break;
			case "4B":
				((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true)", cov.Cov4BRadioactiveMatPermission);
				cov.Cov4BRadioactiveMatPermission.click();
				Thread.sleep(1000);
				break;
			case "13C":
				((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true)", cov.Cov13CLimitationGlass.get(ind));
				cov.Cov13CLimitationGlass.get(ind).click();
				Thread.sleep(1000);
				break;
			case "16":
				((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true)", cov.Cov13CLimitationGlass.get(ind));
				cov.Cov16Suspension.get(ind).click();
				Thread.sleep(1000);
				break;
			case "19":
				((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true)", cov.Cov13CLimitationGlass);
				cov.Cov19LimitAmtIndemnity.click();
				Thread.sleep(1000);
				break;
			case "19A":
				((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true)", cov.Cov13CLimitationGlass);
				cov.Cov19AAgreedValue.click();
				Thread.sleep(1000);
				break;
			case "38":
				((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true)", cov.Cov13CLimitationGlass);
				cov.Cov38AgrIncrLimitElectEqpt.click();
				Thread.sleep(1000);
				break;
			case "40":
				((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true)", cov.Cov13CLimitationGlass.get(ind));
				cov.Cov40FireTheftDed.get(ind).click();
				Thread.sleep(1000);
				break;
			}
		}catch(Exception e){
						
		}
		
	}
	
	
	public void select_Coverage_Endorsements(String str, int ind){
		try{
			switch (str) {
			case "20":
				((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true)", cov.Cov20LossOfUseEndInput_Indicator.get(ind));
				if(!cov.Cov20LossOfUseEndInput_Indicator.get(ind).isSelected()){
					cov.Cov20LossOfUseEndInput_Indicator.get(ind).click();
				}							
				Thread.sleep(1000);
				break;
			case "5":
				((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true)", cov.Cov5RentLeasePermissionInput_Indicator.get(ind));
				if(!cov.Cov5RentLeasePermissionInput_Indicator.get(ind).isSelected()){
					cov.Cov5RentLeasePermissionInput_Indicator.get(ind).click();
				}					
				Thread.sleep(1000);
				break;
			case "23A":
				((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true)", cov.Cov23ALienholderMortgInput_Indicator.get(ind));
				if (!cov.Cov23ALienholderMortgInput_Indicator.get(ind).isSelected()) {
					cov.Cov23ALienholderMortgInput_Indicator.get(ind).click();
				}
				Thread.sleep(1000);
				break;
			case "43A":
				((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true)", cov.CovDeprWaiverLeasedVehInput_Indicator.get(ind));
				if (!cov.CovDeprWaiverLeasedVehInput_Indicator.get(ind).isSelected()) {
					cov.CovDeprWaiverLeasedVehInput_Indicator.get(ind).click();
				}
				Thread.sleep(1000);
				break;
			case "44R":
				((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true)", cov.Cov44FamilyProtectionInput_Indicator.get(ind));
				if (!cov.Cov44FamilyProtectionInput_Indicator.get(ind).isSelected()) {
					cov.Cov44FamilyProtectionInput_Indicator.get(ind).click();
				}
				Thread.sleep(1000);
				break;

			}
		}catch(Exception e){
						
		}
	
}
	
	
	public void unSelect_Coverage_Endorsements(String str, int ind){
			try{
				switch (str) {
				case "20":
					((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true)", cov.Cov20LossOfUseEndInput_Indicator.get(ind));
					if(cov.Cov20LossOfUseEndInput_Indicator.get(ind).isSelected()){
						cov.Cov20LossOfUseEndInput_Indicator.get(ind).click();
					}							
					Thread.sleep(1000);
					break;
				case "5":
					((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true)", cov.Cov5RentLeasePermissionInput_Indicator.get(ind));
					if(cov.Cov5RentLeasePermissionInput_Indicator.get(ind).isSelected()){
						cov.Cov5RentLeasePermissionInput_Indicator.get(ind).click();
					}					
					Thread.sleep(1000);
					break;
				case "23A":
					((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true)", cov.Cov23ALienholderMortgInput_Indicator.get(ind));
					if (cov.Cov23ALienholderMortgInput_Indicator.get(ind).isSelected()) {
						cov.Cov23ALienholderMortgInput_Indicator.get(ind).click();
					}
					Thread.sleep(1000);
					break;
				case "43A":
					((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true)", cov.CovDeprWaiverLeasedVehInput_Indicator.get(ind));
					if (cov.CovDeprWaiverLeasedVehInput_Indicator.get(ind).isSelected()) {
						cov.CovDeprWaiverLeasedVehInput_Indicator.get(ind).click();
					}
					Thread.sleep(1000);
					break;
				case "44R":
					((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true)", cov.Cov44FamilyProtectionInput_Indicator.get(ind));
					if (cov.Cov44FamilyProtectionInput_Indicator.get(ind).isSelected()) {
						cov.Cov44FamilyProtectionInput_Indicator.get(ind).click();
					}
					Thread.sleep(1000);
					break;
				/*case "43":
					((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true)", cov.CovDeprWaiverInput_Indicator.get(ind));
					if (cov.CovDeprWaiverInput_Indicator.get(ind).isSelected()) {
						cov.CovDeprWaiverInput_Indicator.get(ind).click();
					}
					break;*/

				}
			}catch(Exception e){
							
			}
		
	}

	
	public void policy_Level_Endorsements(XWPFDocument docx,XWPFRun run,FileOutputStream out){
		try{
		
			try {
				((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true)", cov.PolicyLevelEndorsements);
				cov.PolicyLevelEndorsements.click();
				
				((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true)", cov.Cov27LiabDamageNOAInput_Indicator);
				if(cov.Cov27LiabDamageNOAInput_Indicator.isSelected()){
					cov.Cov27LiabDamageNOAInput_Indicator.click();
				}
			} catch (Exception e) {

			}
			
			try {
				((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true)", cov.CovOneDedEndInput_Indicator);
				if(cov.CovOneDedEndInput_Indicator.isSelected()){
					cov.CovOneDedEndInput_Indicator.click();
				}
			} catch (Exception e) {

			}
			RM.captureScreenShot(docx,run,out);
		}catch(Exception e){
			System.out.println("Failed in Policy Level Endorsements");
		}
	}



}
