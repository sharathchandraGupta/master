package modules;

import java.io.FileOutputStream;
import java.util.List;

import org.apache.poi.xwpf.usermodel.XWPFDocument;
import org.apache.poi.xwpf.usermodel.XWPFRun;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import utils.Parameters;
import utils.Reusable_Methods;

public class Assignment {
	WebDriver driver;
	pages.Assignment a;
	Reusable_Methods RM;
	
	public Assignment(WebDriver webdriver) {
		driver=webdriver;
		a=new pages.Assignment(driver);
		RM = new Reusable_Methods(driver);			
	}
	public void Driver_Assignment(XWPFDocument docx,XWPFRun run,FileOutputStream out) throws Exception{
		int no_vehicles = Integer.parseInt(Parameters.Vehicles_For_Driver_Assignment);
		String[] str_No_Drivers_to_Assigne =  Parameters.No_Driver_Assignment.split("#");
	
		for(int vehicles=0;vehicles<no_vehicles;vehicles++){
			
			List<WebElement> ele_EditButtons = driver.findElements(By.xpath("//*[@fieldref='RiskCommercialAutoOutputNonShredded.VehicleDescriptionForAssignment']/../../following-sibling::div//*[contains(text(),'Edit')]"));
			ele_EditButtons.get(vehicles).click();
			
			for(int drivers=0;drivers<Integer.parseInt(str_No_Drivers_to_Assigne[vehicles]);drivers++){
				try {
					if(drivers==0)
					driver.switchTo().frame(0);					
					//Assigne the Driver
					assigne_Driver(drivers,vehicles);
				} catch (Exception e) {					
					e.printStackTrace();
					System.out.println("Failed to Add Driver at"+drivers);
				}
			}
			
			a.Save.click();
			Thread.sleep(8000);
			driver.switchTo().defaultContent();
		}
		RM.captureScreenShot(docx,run,out);
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("window.scrollBy(0,1500)");
		driver.findElement(By.xpath("//*[@class='g-btn-text'][contains(text(),'Next')]")).click();
		Thread.sleep(6000);
	}
	
	public void nonOwned_Driver_Assignment(XWPFDocument docx,XWPFRun run,FileOutputStream out) throws Exception{
		int no_vehicles = Integer.parseInt(Parameters.Vehicles_For_Driver_Assignment);
		String[] str_No_Drivers_to_Assigne =  Parameters.No_Driver_Assignment.split("#");
	
		for(int vehicles=0;vehicles<no_vehicles;vehicles++){
			
			List<WebElement> ele_EditButtons = driver.findElements(By.xpath("//*[@fieldref='RiskCommercialAutoOutputNonShredded.VehicleDescriptionForAssignment']/../../following-sibling::div//*[contains(text(),'Edit')]"));
			ele_EditButtons.get(vehicles).click();
			
			for(int drivers=0;drivers<Integer.parseInt(str_No_Drivers_to_Assigne[vehicles]);drivers++){
				try {
					if(drivers==0)
					driver.switchTo().frame(0);					
					//Assigne the Driver
					assigne_Driver(drivers,vehicles);
				} catch (Exception e) {					
					e.printStackTrace();
					System.out.println("Failed to Add Driver at"+drivers);
				}
			}
			
			a.Save.click();
			Thread.sleep(8000);
			driver.switchTo().defaultContent();
		}
		RM.captureScreenShot(docx,run,out);
		/*JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("window.scrollBy(0,1500)");
		driver.findElement(By.xpath("//*[@class='g-btn-text'][contains(text(),'Next')]")).click();
		Thread.sleep(6000);*/
		Driver_Assignment_ForNonOwned(docx,run,out);
	}
	
	public void Driver_Assignment_ForNonOwned(XWPFDocument docx,XWPFRun run,FileOutputStream out) throws Exception{
		int no_vehicles = Integer.parseInt(Parameters.Vehicles_For_Driver_Assignment);
		String[] str_No_Drivers_to_Assigne =  Parameters.No_Driver_Assignment.split("#");
	
		for(int vehicles=0;vehicles<no_vehicles;vehicles++){
			
			List<WebElement> ele_EditButtons = driver.findElements(By.xpath("//*[@fieldref='RiskVehicleInput.Description']/../../following-sibling::div//*[contains(text(),'Edit')]"));
			ele_EditButtons.get(vehicles).click();
			
			for(int drivers=0;drivers<Integer.parseInt(str_No_Drivers_to_Assigne[vehicles]);drivers++){
				try {
					if(drivers==0)
					driver.switchTo().frame(0);					
					//Assigne the Driver
					assigne_Driver(drivers,vehicles);
				} catch (Exception e) {					
					e.printStackTrace();
					System.out.println("Failed to Add Driver at"+drivers);
				}
			}
			
			a.Save.click();
			Thread.sleep(8000);
			driver.switchTo().defaultContent();
		}
		RM.captureScreenShot(docx,run,out);
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("window.scrollBy(0,1500)");
		driver.findElement(By.xpath("//*[@class='g-btn-text'][contains(text(),'Next')]")).click();
		Thread.sleep(6000);
	}
		
	public void assigne_Driver(int row_No, int vehicles) throws Exception{
		String[] driver_ForVechel =null;
		try {
			//To click on Unassign button
			if(row_No==0){
				try{	
					Thread.sleep(3000);
					a.driver_Unassign_Btn.click();
				}
				catch(Exception unssigned_Btn){
					System.out.println("Failed to click on unassigned button");
					System.out.println(unssigned_Btn.getMessage());
				}
			}
			
			//To click on Assinge button
			Thread.sleep(2000);
			a.driver_Assing_Btn.click();
			Thread.sleep(1000);
			
			//To Enter the Driver
			List<WebElement> ele_DriverInput = driver.findElements(By.xpath("//*[@fieldref='AssignedDriverInput.DriverID']"));
			
			ele_DriverInput.get(row_No).sendKeys(Parameters.Driver_Assignment.split("_")[vehicles].split("#")[row_No]);
			Thread.sleep(1000);
			ele_DriverInput.get(row_No).sendKeys(Keys.TAB);
			Thread.sleep(1000);
			
			
			
			//To Enter the Assignment
			List<WebElement> ele_DriverAssignment = driver.findElements(By.xpath("//*[@fieldref='AssignedDriverInput.Type']"));		
			ele_DriverAssignment.get(row_No).sendKeys(Parameters.Assignment_ForDriver.split("_")[vehicles].split("#")[row_No]);
			Thread.sleep(1000);
			ele_DriverAssignment.get(row_No).sendKeys(Keys.TAB);
			Thread.sleep(1000);
			
			//To Enter the YearVehicleAndCommodityExp
			try {
				List<WebElement> ele_YearVehicleAndCommodityExp = driver.findElements(By.xpath("//*[@fieldref='AssignedDriverInput.YearVehicleAndCommodityExp']"));		
				ele_YearVehicleAndCommodityExp.get(row_No).sendKeys(Parameters.Assignment_YearVehicleAndCommodityExp.split("_")[vehicles].split("#")[row_No]);
				Thread.sleep(1000);
				ele_YearVehicleAndCommodityExp.get(row_No).sendKeys(Keys.TAB);
				Thread.sleep(1000);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		} catch (Exception e) {
			System.out.println("Failed in driver Assignment" +row_No);
			e.printStackTrace();
		}
	}


}
