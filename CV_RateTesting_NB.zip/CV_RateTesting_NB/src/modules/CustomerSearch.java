package modules;

import java.io.FileOutputStream;

import org.apache.poi.hwpf.usermodel.Paragraph;
import org.apache.poi.xwpf.usermodel.XWPFDocument;
import org.apache.poi.xwpf.usermodel.XWPFRun;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import com.beust.jcommander.Parameter;

import utils.Parameters;
import utils.Reusable_Methods;

public class CustomerSearch {
	WebDriver driver;
	pages.CustomerSearch c;
	Reusable_Methods RM;

	public CustomerSearch(WebDriver webdriver) {
		driver = webdriver;
		c = new pages.CustomerSearch(driver);
		RM = new Reusable_Methods(driver);
	}

	public void customerSearch(XWPFDocument docx,XWPFRun run,FileOutputStream out) throws InterruptedException {
		try {
			c.advanceSearch.click();
			Thread.sleep(3000);
			boolean flag = RM.verify_PageTitle(driver, "Advanced Search");
			try {
				Assert.assertEquals(flag, true);
			} catch (AssertionError e) {
				e.printStackTrace();
				System.out.println("Failed to Navigate to Advanced Search page");
			}
			c.customerSelect.click();
			Thread.sleep(3000);
			c.customerName.sendKeys(RM.getRandomString());
			c.search.click();
			WebDriverWait wait = new WebDriverWait(driver, 20);
			wait.until(ExpectedConditions.visibilityOf(c.createNewClient));
			c.createNewClient.click();
			Thread.sleep(2000);
			if(Parameters.EffectiveDate.isEmpty() || Parameters.EffectiveDate.equals("")){
				c.enterDate.sendKeys(RM.getDate());
			}else{
				c.enterDate.sendKeys(Parameters.EffectiveDate);
			}
			
			RM.captureScreenShot(docx,run,out);
			c.ok.click();
			Thread.sleep(6000);
		} catch (Exception e) {
			System.out.println("Failed to Search the Customer in Advanced Search Page");
			e.printStackTrace();
		}
	}
}
