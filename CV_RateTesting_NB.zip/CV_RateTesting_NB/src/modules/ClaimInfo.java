package modules;

import java.io.FileOutputStream;

import org.apache.poi.xwpf.usermodel.XWPFDocument;
import org.apache.poi.xwpf.usermodel.XWPFRun;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import utils.Parameters;
import utils.Reusable_Methods;

public class ClaimInfo {
	Reusable_Methods RM;
	WebDriver driver;
	pages.ClaimInfo c;

	public ClaimInfo(WebDriver webdriver) {
		driver = webdriver;
		c = new pages.ClaimInfo(driver);
		RM = new Reusable_Methods(driver);

	}
	
	public void ClaimInfo(XWPFDocument docx,XWPFRun run,FileOutputStream out) throws Exception {
		try {
			for (int claims = 0; claims < Parameters.No_of_Claims_ToBeAdded; claims++) {
				
				((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true)", c.AddClaim);
				RM.wait_For_Element(c.AddClaim);				
				Thread.sleep(1000);
				c.AddClaim.click();
				try {
					Thread.sleep(3000);
					driver.switchTo().frame(0);
				} catch (Exception e) {

				}
				c.Next.click();

				c.DateofLoss.sendKeys(Parameters.Claim_Date.split("#")[claims]);
				Thread.sleep(1000);
				c.DateofLoss.sendKeys(Keys.TAB);
				Thread.sleep(2000);

				c.DescriptionofLoss.sendKeys(Parameters.Claim_Desc_Of_Loss.split("#")[claims]);
				Thread.sleep(1000);
				c.DescriptionofLoss.sendKeys(Keys.TAB);
				Thread.sleep(2000);

				c.ClaimInputVehicle.sendKeys(Parameters.Claim_Vehicle.split("#")[claims]);
				Thread.sleep(1000);
				c.ClaimInputVehicle.sendKeys(Keys.TAB);
				Thread.sleep(2000);

				try {
					if (c.ClaimInputDriver.isDisplayed()) {
						c.ClaimInputDriver.sendKeys(Parameters.Claim_Driver.split("#")[claims].trim());
						Thread.sleep(1000);
						c.ClaimInputDriver.sendKeys(Keys.TAB);
						Thread.sleep(2000);
					}
				} catch (Exception e) {

				}

				c.AssignLoss.sendKeys(Parameters.Claim_AssignLoss.split("#")[claims]);
				Thread.sleep(1000);
				c.AssignLoss.sendKeys(Keys.TAB);
				Thread.sleep(2000);

				c.TotalPaid.clear();
				c.TotalPaid.sendKeys(Parameters.Claim_TotalPaid.split("#")[claims]);
				Thread.sleep(1000);
				c.TotalPaid.sendKeys(Keys.TAB);
				Thread.sleep(1000);

				c.Reserve.clear();
				c.Reserve.sendKeys(Parameters.Claim_Reserve.split("#")[claims]);
				Thread.sleep(1000);
				c.Reserve.sendKeys(Keys.TAB);
				Thread.sleep(1000);

				c.RatingType.sendKeys(Parameters.Claim_Reserve_Type.split("#")[claims]);
				Thread.sleep(1000);
				c.RatingType.sendKeys(Keys.TAB);
				Thread.sleep(1000);

				c.OK.click();
				Thread.sleep(4000);
				try {
					driver.switchTo().defaultContent();
				} catch (Exception e) {

				}

			}
		} catch (Exception e) {
			System.out.println("Failed to create claim");
			e.printStackTrace();
		}
		RM.captureScreenShot(docx,run,out);
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("window.scrollBy(0,1500)");
		driver.findElement(By.xpath("//*[@class='g-btn-text'][contains(text(),'Next')]")).click();
		Thread.sleep(8000);
	
	}

}
