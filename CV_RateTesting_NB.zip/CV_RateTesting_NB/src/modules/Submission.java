
package modules;

import java.io.FileOutputStream;

import org.apache.poi.xwpf.usermodel.XWPFDocument;
import org.apache.poi.xwpf.usermodel.XWPFRun;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;

import utils.Parameters;
import utils.Reusable_Methods;

public class Submission {
	WebDriver driver;
	pages.Submission s;
	Reusable_Methods RM;

	public Submission(WebDriver webdriver) {
		driver = webdriver;
		s = new pages.Submission(driver);
		RM = new Reusable_Methods(driver);
	}

	public void submission(XWPFDocument docx,XWPFRun run,FileOutputStream out) throws InterruptedException {
		
		try {
			if (!Parameters.brokerName.equals("")) {
				s.brokerName.sendKeys(Parameters.brokerName);
				Thread.sleep(2000);
				s.brokerName.sendKeys(Keys.TAB);
				Thread.sleep(2000);
			}
			
			s.brokerLocation.click();
			Thread.sleep(2000);
			s.brokerLocation.sendKeys(Keys.ARROW_DOWN);
			Thread.sleep(1000);
			s.brokerLocation.sendKeys(Keys.ARROW_DOWN);
			Thread.sleep(1000);
			s.brokerLocation.sendKeys(Keys.TAB);
			s.SalesInitiative.click();
			Thread.sleep(2000);
			s.brokerLocation.sendKeys(Keys.ARROW_DOWN);
			Thread.sleep(1000);
			s.brokerLocation.sendKeys(Keys.ARROW_DOWN);
			Thread.sleep(1000);
			s.brokerLocation.sendKeys(Keys.TAB);
			Thread.sleep(2000);
			
			JavascriptExecutor js = (JavascriptExecutor) driver;
			js.executeScript("window.scrollBy(0,1500)");
			
			if (Parameters.commercialProperty.equalsIgnoreCase("YES")) {
				if (!s.commercialProperty.isSelected()) {
					s.commercialProperty.click();
				}
			} else {
				if (s.commercialProperty.isSelected()) {
					s.commercialProperty.click();
				}
			}
			
			
			js.executeScript("window.scrollBy(0,600)");
			s.yearBusinessEstablished.sendKeys(Integer.toString(Parameters.yearBusinessEstablished));
			s.yearBusinessEstablished.sendKeys(Keys.TAB);
			Thread.sleep(1000);
			
			s.fullTimeEmploys.sendKeys(Integer.toString(Parameters.fullTimeEmploys));
			s.fullTimeEmploys.sendKeys(Keys.TAB);
			Thread.sleep(1000);
			
			if (Parameters.NewVenture.equalsIgnoreCase("YES")) {
				s.NewVenture.click();
			} else {
				if (Parameters.commercialProperty.equalsIgnoreCase("YES")) {
				s.currentInsurer.sendKeys(Parameters.currentInsurer);
				Thread.sleep(1000);
				s.currentInsurer.sendKeys(Keys.TAB);
				Thread.sleep(1000);
				}
			}

		
			((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true)", s.bineBusinessInterruptionInput);
			if (Parameters.businessInterruptionInput.equalsIgnoreCase("YES")) {
				if (!s.bineBusinessInterruptionInput.isSelected()) {
					s.bineBusinessInterruptionInput.click();
				}
			} else {
				if (s.bineBusinessInterruptionInput.isSelected()) {
					s.bineBusinessInterruptionInput.click();
				}
			}
			

			if (Parameters.inlandMarineInput.equalsIgnoreCase("YES")) {
				if (!s.inlandMarineInput.isSelected()) {
					s.inlandMarineInput.click();
				}
			} else {
				if (s.inlandMarineInput.isSelected()) {
					s.inlandMarineInput.click();
				}
			}

			if (Parameters.liability.equalsIgnoreCase("YES")) {
				if (!s.liabilityIndicator.isSelected()) {
					s.liabilityIndicator.click();
				}
			} else {
				if (s.liabilityIndicator.isSelected()) {
					s.liabilityIndicator.click();
				}
			}
			
			//To add
			((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true)", s.LineCrimeInput);
			if (Parameters.LineCrimeInput.equalsIgnoreCase("YES")) {
				if (!s.LineCrimeInput.isSelected()) {
					s.LineCrimeInput.click();
				}
			} else {
				if (s.LineCrimeInput.isSelected()) {
					s.LineCrimeInput.click();
				}
			}
			if (!s.LineCommercialAutoInput_Indicator.isSelected()) {
				s.LineCommercialAutoInput_Indicator.click();
			}

			if (!Parameters.NewVenture.equalsIgnoreCase("YES")) {
				s.Commercial_CurrentInsurer.sendKeys(Parameters.CommercialAutoCurrentInsurer);
				Thread.sleep(1000);
				s.Commercial_CurrentInsurer.sendKeys(Keys.TAB);
				s.YearsCurrentInsurer.sendKeys(Parameters.YearsCurrentInsurer);
			}
			RM.captureScreenShot(docx,run,out);
			js.executeScript("window.scrollBy(0,1500)");
			driver.findElement(By.xpath("//*[@class='g-btn-text'][contains(text(),'Next')]")).click();
			Thread.sleep(6000);
		} catch (Exception e) {
			System.out.println("Failed to Enter Details of Submission Page");
			e.printStackTrace();
		}
	}
}
