package modules;

import java.io.FileOutputStream;

import org.apache.poi.xwpf.usermodel.XWPFDocument;
import org.apache.poi.xwpf.usermodel.XWPFRun;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import utils.Parameters;
import utils.Reusable_Methods;

public class Location {
	WebDriver driver;
	pages.Location l;
	Reusable_Methods RM;

	public Location(WebDriver webdriver) {
		driver = webdriver;
		l = new pages.Location(driver);
		RM = new Reusable_Methods(driver);

	}

	public void location(XWPFDocument docx,XWPFRun run,FileOutputStream out) throws Exception {
		
		try {
			driver.findElement(By.xpath("//*[@class='g-btn-text'][contains(text(),'Get Town Grade')]")).click();
			RM.wait_For_Element(l.typeOfConstruction);
			Thread.sleep(2000);

			RM.wait_For_Element(l.TownGrade);
			Thread.sleep(4000);
			try {
				((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true)", l.TownGrade);
				l.TownGrade.clear();
				l.TownGrade.click();
				l.TownGrade.sendKeys("01");
				l.TownGrade.sendKeys(Keys.ARROW_DOWN);
				l.TownGrade.sendKeys(Keys.TAB);
			} catch (Exception e) {

			}
			
			JavascriptExecutor js = (JavascriptExecutor) driver;
			js.executeScript("window.scrollBy(0,1500)");
			
			l.typeOfConstruction.sendKeys(Parameters.typeOfConstruction);
			l.typeOfConstruction.sendKeys(Keys.TAB);

			Thread.sleep(2000);
			l.noOfStoreys.sendKeys(Integer.toString(Parameters.noOfStoreys));

			l.yearBuilt.sendKeys(Integer.toString(Parameters.yearBuilt));

			l.area.sendKeys(Integer.toString(Parameters.area));
			Thread.sleep(2000);
			if(Parameters.BuildingLimit!=0){
				if(!l.BuildingIndicatorCheckbox.isSelected()){
					l.BuildingIndicatorCheckbox.click();
					Thread.sleep(2000);
					l.CovBuildingLimitInput.sendKeys(Integer.toString(Parameters.BuildingLimit));
					l.CovBuildingLimitInput.sendKeys(Keys.TAB);
					Thread.sleep(2000);
				}
			}
			
			if(Parameters.BusinessPersonalProperty!=0){
				l.BusinessPersonalProperty.clear();			
				Thread.sleep(1000);	
				l.BusinessPersonalProperty.sendKeys(Integer.toString(Parameters.BusinessPersonalProperty));
				l.BusinessPersonalProperty.sendKeys(Keys.TAB);
				Thread.sleep(2000);
			}						
			RM.captureScreenShot(docx,run,out);		
			Thread.sleep(5000);
			WebElement ele_Next = driver.findElement(By.xpath("//*[@class='g-btn-text'][contains(text(),'Next')]"));
			((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true)", ele_Next);
			ele_Next.click();
			Thread.sleep(5000);
		} catch (Exception e) {
			System.out.println("Failed in Location Module");
			e.printStackTrace();
		}
	}

}
