package pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

public class Assignment {
	
	WebDriver driver;
	public Assignment( WebDriver webdriver) {
		driver=webdriver;
		PageFactory.initElements(driver, this);
		
	}

	@FindBy(how=How.XPATH,using="//*[@class='g-btn-text'][contains(text(),'Edit')]")
	public WebElement Edit;
	
	@FindBy(how=How.XPATH,using="//*[@fieldref='AssignedDriverInput.DriverID']")
	public WebElement DriverID;
		
	@FindBy(how=How.XPATH,using="//*[@fieldref='AssignedDriverInput.Type']")
	public WebElement Assignment;
		
	@FindBy(how=How.XPATH,using="//*[@class='g-btn-text'][contains(text(),'Save')]")
	public WebElement Save;
	
	@FindBy(how=How.XPATH,using="//span[contains(text(),'Assign')]")
	public WebElement driver_Assing_Btn;
	
	@FindBy(how=How.XPATH,using="//span[contains(text(),'Unassign')]")
	public WebElement driver_Unassign_Btn;
	
	
	
	
	
	
};
