package pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

public class Submission {
	
	WebDriver driver;
	public Submission( WebDriver webdriver) {
		driver=webdriver;
		PageFactory.initElements(driver, this);
		
	}

	@FindBy(how=How.XPATH,using="//*[@fieldref='PolicyInput.NameBoker']|//*[@fieldref='PolicyInput.Name']")
	public WebElement brokerName;
		
	@FindBy(how=How.XPATH,using="//*[@fieldref='PolicyInput.Location']")
	public WebElement brokerLocation;
	
	@FindBy(how=How.XPATH,using="//*[@fieldref='SalesInitiativeInput.SalesInitiative']")
	public WebElement SalesInitiative;
			
	@FindBy(how=How.XPATH,using="//*[@fieldref='PolicyInput.CurrentInsurer']")
	public WebElement currentInsurer;
	
	@FindBy(how=How.XPATH,using="//*[@fieldref='PolicyInput.YearBusinessEstablished']")
	public WebElement yearBusinessEstablished;
	
	@FindBy(how=How.XPATH,using="//*[@fieldref='PolicyInput.NumberOfFullTimeEmployees']")
	public WebElement fullTimeEmploys;
	
	@FindBy(how=How.XPATH,using="//*[@fieldref='LineCommercialPropertyInput.Indicator']")
	public WebElement commercialProperty;
	
	@FindBy(how=How.XPATH,using="//*[@fieldref='PolicyInput.LiabilityIndicator']")
	public WebElement liabilityIndicator;
	
	@FindBy(how=How.XPATH,using="//*[@fieldref='LineInlandMarineInput.Indicator']")
	public WebElement inlandMarineInput;
	
	@FindBy(how=How.XPATH,using="//*[@fieldref='LineBusinessInterruptionInput.Indicator']")
	public WebElement bineBusinessInterruptionInput;
	
	@FindBy(how=How.XPATH,using="//*[@fieldref='LineCommercialAutoInput.Indicator']")
	public WebElement LineCommercialAutoInput;
	
	@FindBy(how=How.XPATH,using="//*[@fieldref='LineCommercialAutoInput.CurrentInsurer']")
	public WebElement CommercialAutoCurrentInsurer;
	
	
	
	@FindBy(how=How.XPATH,using="//*[@fieldref='LineCrimeInput.Indicator']")
	public WebElement LineCrimeInput;
	
	@FindBy(how=How.XPATH,using="//*[@fieldref='PolicyInput.AutoIndicator']")
	public WebElement LineCommercialAutoInput_Indicator;
	
	@FindBy(how=How.XPATH,using="//*[@fieldref='LineCommercialAutoInput.CurrentInsurer']")
	public WebElement Commercial_CurrentInsurer;
		
	@FindBy(how=How.XPATH,using="//*[@fieldref='PolicyInput.NewVenture']")
	public WebElement NewVenture;
	
	@FindBy(how=How.XPATH,using="//*[@fieldref='LineCommercialAutoInput.YearsCurrentInsurer']")
	public WebElement YearsCurrentInsurer;
		
	@FindBy(how=How.XPATH,using="//*[@id='p743EFECD40E445659FB5400E5344271410E_4_1_anchorId']/div[2]/span")
	public WebElement next;
	
};
