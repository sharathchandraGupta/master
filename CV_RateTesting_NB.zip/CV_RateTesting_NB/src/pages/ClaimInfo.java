package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

public class ClaimInfo {
	
	WebDriver driver;
	public ClaimInfo( WebDriver webdriver) {
		driver=webdriver;
		PageFactory.initElements(driver, this);
		
	}

		
	@FindBy(how=How.XPATH,using="//img[@class='g-btn-img-loneIcon']")
	public WebElement AddClaim;
	
	@FindBy(how=How.XPATH,using="//*[@class='g-btn-text'][contains(text(),'Next')]")
	public WebElement Next;
	
	@FindBy(how=How.XPATH,using="//*[@fieldref='ClaimInput.DateofLoss']")
	public WebElement DateofLoss;
	
	@FindBy(how=How.XPATH,using="//*[@fieldref='ClaimInput.DescriptionofLoss']")
	public WebElement DescriptionofLoss;
	
	@FindBy(how=How.XPATH,using="//*[@fieldref='ClaimInput.Vehicle']")
	public WebElement ClaimInputVehicle;
	
	@FindBy(how=How.XPATH,using="//*[@fieldref='ClaimInput.AssignLoss']")
	public WebElement AssignLoss;
	
	@FindBy(how=How.XPATH,using= "//*[@fieldref='ClaimInput.Driver']")
	public WebElement ClaimInputDriver;
	
	@FindBy(how=How.XPATH,using="//*[@fieldref='ClaimInput.TotalPaid']")
	public WebElement TotalPaid;
	
	@FindBy(how=How.XPATH,using="//*[@fieldref='ClaimInput.Reserve']")
	public WebElement Reserve;
	
	@FindBy(how=How.XPATH,using="//*[@fieldref='ClaimInput.RatingType']")
	public WebElement RatingType;
	//*[text()='OK']
	@FindBy(how=How.XPATH,using="//*[@class='g-btn-text'][contains(text(),'OK')]")
	public WebElement OK;
	
	
};
