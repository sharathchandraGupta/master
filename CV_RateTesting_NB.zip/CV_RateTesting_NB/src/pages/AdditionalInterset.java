package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

public class AdditionalInterset {
	
	WebDriver driver;
	public AdditionalInterset( WebDriver webdriver) {
		driver=webdriver;
		PageFactory.initElements(driver, this);
		
	}

		
	@FindBy(how=How.XPATH,using="//*[@class='g-btn-text'][contains(text(),'Add Additional Interest')]")
	public WebElement AddAdditionalInterest;
	
	
	@FindBy(how=How.XPATH,using="//*[@fieldref='AdditionalOtherInterestInput.Type']")
	public WebElement AdditionalIntersetType;
	
	@FindBy(how=How.XPATH,using="//*[@fieldref='AdditionalOtherInterestInput.Name']")
	public WebElement AdditionalInterestName;
	
	@FindBy(how=How.XPATH,using="//*[@fieldref='AdditionalOtherInterestInput.CareOff']")
	public WebElement CareOff;
	
	@FindBy(how=How.XPATH,using="//*[@fieldref='AdditionalOtherInterestInput.Address']")
	public WebElement Address;
	
	
	@FindBy(how=How.XPATH,using="//*[img[@class='g-btn-img-loneIcon']]")
	public WebElement AddressSearch;
			
	@FindBy(how=How.XPATH,using="//*[@class='g-btn-text'][contains(text(),'Save')]")
	public WebElement Save;
	
	
};
