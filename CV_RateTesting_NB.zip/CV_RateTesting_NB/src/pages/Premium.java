package pages;

import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

public class Premium {
	
	WebDriver driver;
	public Premium( WebDriver webdriver) {
		driver=webdriver;
		PageFactory.initElements(driver, this);		
	}

	@FindBy(how=How.XPATH,using="//*[@fieldref='PolicyInput.QuotePremium']")
	public WebElement quotePremium;
	
	@FindBy(how=How.XPATH,using="//*[contains(text(),'Approve')]")
	public WebElement getTownGrade;
	
	@FindBy(how=How.XPATH,using="//*[@fieldref='CovAutomaticBlanketCoverageExtensionInput.Limit']")
	public WebElement CoverageLimit;
	
	@FindBy(how=How.XPATH,using="//*[@fieldref='CovAutomaticBlanketCoverageExtensionOutput.CalculatedPremium']")
	public WebElement CoveragePremium;
	
	@FindBy(how=How.XPATH,using="//span[text()='Auto']")
	public WebElement Auto;
	
	@FindBy(how=How.XPATH,using="//div[text()='Auto']")
	public WebElement AutoPremium;
	
	@FindBy(how=How.XPATH,using="//*[@id='body']/div[2]/div[6]/div/div/div[@class='toggleHeader toggle-collapsed']/div")
	public List<WebElement> Premium_Vehicle;
	
	
	@FindBy(how=How.XPATH,using="//span[contains(text(),'Back to Premium Summary')]")
	public WebElement Back_to_Premium_Summary;
	
	@FindBy(how=How.XPATH,using="//label[contains(text(),'Calculated Premium')]/parent::div/parent::div/div[2]/div/div")
	public WebElement Capture_CalculatedPremium;
	
	@FindBy(how=How.XPATH,using="//span[contains(text(),'Quote')]")
	public WebElement quote_Button;
	
	@FindBy(how=How.XPATH,using="//span[contains(text(),'Bind')]")
	public WebElement bind_Button;
	
	@FindBy(how=How.XPATH,using="//span[contains(text(),'Book')]")
	public WebElement book_Button;

	
	@FindBy(how=How.XPATH,using="//*[@fieldref='CovThirdPartyLiabilityOutput.CalculatedPremium']")
	public List<WebElement> CovTPLBodilyInjuryOutput;
	
	
	@FindBy(how=How.XPATH,using="//*[@fieldref='CovTPLDirectCompensationOutput.CalculatedPremium']")
	public List<WebElement> CovTPLDirectCompensationOutput;
	
	@FindBy(how=How.XPATH,using="//*[@fieldref='CovTPLPropertyDamageOutput.CalculatedPremium']")
	public List<WebElement> CovTPLPropertyDamageOutput;
										
	@FindBy(how=How.XPATH,using="//*[@fieldref='CovAccidentBenefitsOutput.CalculatedPremium']")
	public List<WebElement> CovAccidentBenefitsOutput;
	
	@FindBy(how=How.XPATH,using="//*[@fieldref='CovUninsuredAutomobileOutput.CalculatedPremium']")
	public List<WebElement> CovUninsuredAutomobileOutput;
	
	@FindBy(how=How.XPATH,using="//*[@fieldref='CovComprehensiveOutput.CalculatedPremium']")
	public List<WebElement> CovComprehensiveOutput;
	
	@FindBy(how=How.XPATH,using="//*[@fieldref='CovCollisionOutput.CalculatedPremium']")
	public List<WebElement> CovCollisionOutput;
		
	@FindBy(how=How.XPATH,using="//*[@fieldref='Cov44FamilyProtectionOutput.CalculatedPremium']")
	public List<WebElement> Cov44FamilyProtectionOutput;
	
	@FindBy(how=How.XPATH,using="//*[@fieldref='PolicyInput.QuotePremiumAutoDisplay']")
	public WebElement Auto_Final_Premium;
	
	@FindBy(how=How.XPATH,using="//*[@fieldref='CovAllPerilsOutput.CalculatedPremium']")
	public List<WebElement> CovAllPerilsOutput;
	
	@FindBy(how=How.XPATH,using="//*[@fieldref='CovSpecifiedPerilsOutput.CalculatedPremium']")
	public List<WebElement> CovSpecifiedPerilsOutput;
	
	
	
	
	
	
};
