package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

public class Billing {
	
	WebDriver driver;
	public Billing( WebDriver webdriver) {
		driver=webdriver;
		PageFactory.initElements(driver, this);
		
	}


	@FindBy(how=How.XPATH,using="//*[@fieldref='BillingInput.BillingType' and value='DirectBill']")
	public WebElement DirectBillingType;
	
	@FindBy(how=How.XPATH,using="//*[@fieldref='BillingInput.BillingType' and value='BrokerBill']")
	public WebElement BrokerBillingType;
	
	@FindBy(how=How.XPATH,using="//*[@fieldref='AdditionalOtherInterestInput.Name']")
	public WebElement AdditionalInterestName;
	
	@FindBy(how=How.XPATH,using="//*[@fieldref='AdditionalOtherInterestInput.CareOff']")
	public WebElement CareOff;
	
	@FindBy(how=How.XPATH,using="//*[@fieldref='AdditionalOtherInterestInput.Address']")
	public WebElement Address;
	
	@FindBy(how=How.XPATH,using= "//*[@fieldref='ClaimInput.Driver']")
	public WebElement ClaimInputDriver;
	
	@FindBy(how=How.XPATH,using="//*[img[@class='g-btn-img-loneIcon']]")
	public WebElement AddressSearch;
			
	@FindBy(how=How.XPATH,using="//*[@class='g-btn-text'][contains(text(),'Save')]")
	public WebElement Save;
	
	@FindBy(how=How.XPATH,using="//span[contains(text(),'Next')]")
	public WebElement Next_Button;
	
};
