package pages;


import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

public class PageTitle {
	WebDriver driver ;

	public PageTitle(WebDriver webdriver) {
		driver=webdriver;
		PageFactory.initElements(webdriver, this);
		}

	//Verify Page Title		
	@FindBy(how=How.XPATH,using="//*[@id='pageTitle']")
	public WebElement pageTitle;
	
	

	
}
