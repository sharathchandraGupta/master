package pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

public class Location {
	
	WebDriver driver;
	public Location( WebDriver webdriver) {
		driver=webdriver;
		PageFactory.initElements(driver, this);
		
	}

	@FindBy(how=How.XPATH,using="//*[contains(text(),'Get Town Grade')]")
	public WebElement getTownGrade;
		
	@FindBy(how=How.XPATH,using="//*[@fieldref='BuildingInput.TypeOfConstruction']")
	public WebElement typeOfConstruction;
		
	@FindBy(how=How.XPATH,using="//*[@fieldref='BuildingInput.NoOfStoreys']")
	public WebElement noOfStoreys;
	
	@FindBy(how=How.XPATH,using="//*[@fieldref='BuildingInput.YearBuilt']")
	public WebElement yearBuilt;
	
	@FindBy(how=How.XPATH,using="//*[@fieldref='BuildingInput.Area']")
	public WebElement area;
	
	@FindBy(how=How.XPATH,using="//*[@fieldref='CovBuildingInput.Indicator']")
	public WebElement BuildingIndicatorCheckbox;
	
	@FindBy(how=How.XPATH,using="//*[@fieldref='CovBuildingInput.Limit']")
	public WebElement CovBuildingLimitInput;
	
	@FindBy(how=How.XPATH,using="//*[@fieldref='CovBusinessPersonalPropertyInput.Limit']")
	public WebElement BusinessPersonalProperty;
	
	@FindBy(how=How.XPATH,using="//*[@fieldref='LocationInput.TownGrade']")
	public WebElement TownGrade;	
	
	@FindBy(how=How.XPATH,using="//*[contains(text(),'Next')]")
	public WebElement next;
		
	
	
};
