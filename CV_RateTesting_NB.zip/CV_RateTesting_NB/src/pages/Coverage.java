package pages;

import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.FindBys;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

public class Coverage {
	WebDriver driver;
	public Coverage( WebDriver webdriver) {
		driver=webdriver;
		PageFactory.initElements(driver, this);		
	}

	
	
	
	@FindBy(how=How.XPATH,using="//a[contains(text(),'Coverage')]")
	public WebElement CoverageTab;
	
	@FindBy(how=How.XPATH,using="//*[text()='AUTO']')]")
	public WebElement tab_Auto;
	
	@FindBy(how=How.XPATH,using="//*[@class='toggleHeaderInner'][contains(text(),'PROPERTY')]")
	public WebElement PROPERTYHeader;
	
	@FindBy(how=How.XPATH,using="//*[@class='toggleHeaderInner'][contains(text(),'Commercial Property')]")
	public WebElement CommercialPropertyHeader;
	
	@FindBy(how=How.XPATH,using="//*[@class='toggleHeaderInner'][contains(text(),'Extensions')]")
	public WebElement ExtensionsHeader;
	
	@FindBy(how=How.XPATH,using="//*[@fieldref='CovAutomaticBlanketCoverageExtensionInput.Limit']")
	public WebElement  CoverageExtensionInput;	

	@FindBy(how=How.XPATH,using="//*[@fieldref='PolicyInput.LiabilityIndicator']")
	public WebElement  LiabilityIndicator;
	
	@FindBy(how=How.XPATH,using="//*[@fieldref='Cov4AExplosivePermissionInput.Indicator']")
	public WebElement  Cov4AExplosivePermission;
	
	@FindBy(how=How.XPATH,using="//*[@fieldref='Cov4BRadioactiveMatPermissionInput.Indicator']")
	public WebElement  Cov4BRadioactiveMatPermission;
	
	@FindBy(how=How.XPATH,using="//*[@fieldref='Cov13CLimitationGlassInput.Indicator']")
	public List<WebElement>  Cov13CLimitationGlass;
	
	@FindBy(how=How.XPATH,using="//*[@fieldref='Cov16SuspensionInput.Indicator']")
	public List<WebElement>  Cov16Suspension;
	
	@FindBy(how=How.XPATH,using="//*[@fieldref='Cov19LimitAmtIndemnityInput.Indicator']")
	public WebElement  Cov19LimitAmtIndemnity;
	
	@FindBy(how=How.XPATH,using="//*[@fieldref='Cov19AAgreedValueInput.Indicator']")
	public WebElement  Cov19AAgreedValue;
	
	@FindBy(how=How.XPATH,using="//*[@fieldref='Cov38AgrIncrLimitElectEqptInput.Indicator']")
	public WebElement  Cov38AgrIncrLimitElectEqpt;
	
	@FindBy(how=How.XPATH,using="//*[@fieldref='Cov40FireTheftDedInput.Indicator']")
	public List<WebElement>  Cov40FireTheftDed;
												
	@FindBy(how=How.XPATH,using="//*[@fieldref='CovThirdPartyLiabilityInput.Indicator']")
	public List<WebElement>   CovTPLBodilyInjuryCheckBox;
												
//	@FindBy(how=How.XPATH,using="//*[@fieldref='CovTPLBodilyInjuryInput.Limit']")
	@FindBy(how=How.XPATH,using="//*[@fieldref='CovThirdPartyLiabilityInput.Limit']")
	
	public List<WebElement>   CovTPLBodilyInjuryInput;
	
	
	@FindBy(how=How.XPATH,using="//*[@fieldref='CovTPLPropertyDamageInput.Indicator']")
	public List<WebElement>  CovTPLPropertyDamageInput_CheckBox;
	
	@FindBy(how=How.XPATH,using="//*[@fieldref='CovTPLPropertyDamageInput.Limit']")
	public List<WebElement>  CovTPLPropertyDamageInput_Limit;
		
	@FindBy(how=How.XPATH,using="//*[@fieldref='CovTPLDirectCompensationInput.Indicator']")
	public List<WebElement>  CovTPLDirectCompensation_CheckBox;
	
	@FindBy(how=How.XPATH,using="//*[@fieldref='CovTPLDirectCompensationInput.UIDeductible']")
	public List<WebElement>  CovTPLDirectCompensation_Deductible;	
	
		
	@FindBy(how=How.XPATH,using="//*[@fieldref='CovAllPerilsInput.Indicator']")
	public List<WebElement>  CovAllPerilsInput_Indicator;
	
	@FindBy(how=How.XPATH,using="//*[@fieldref='CovAllPerilsInput.Deductible']")
	public List<WebElement>  CovAllPerilsInput_Deductible;	
	
	@FindBy(how=How.XPATH,using="//*[@fieldref='CovCollisionInput.Indicator']")
	public List<WebElement>  CovCollisionInput_Indicator;
	
	@FindBy(how=How.XPATH,using="//*[@fieldref='CovCollisionInput.Deductible']")
	public List<WebElement>  CovCollisionInput_Deductible;
	
	@FindBy(how=How.XPATH,using="//*[@fieldref='CovComprehensiveInput.Deductible']")
	public List<WebElement>  CovComprehensiveInput_Deductible;
												
	@FindBy(how=How.XPATH,using="//*[@fieldref='CovComprehensiveInput.Indicator']")
	public  List<WebElement>  CovComprehensiveInput_Indicator;
		
	@FindBy(how=How.XPATH,using="//*[@fieldref='CovSpecifiedPerilsInput.Indicator']")
	public  List<WebElement>  CovSpecifiedPerilsInput_CheckBox;
	
	@FindBy(how=How.XPATH,using="//*[@fieldref='CovSpecifiedPerilsInput.Deductible']")
	public  List<WebElement>  CovSpecifiedPerilsInput_Deductible;
	
//	@FindBy(how=How.XPATH,using="//*[text()='Endorsements']")
	@FindBy(how=How.XPATH,using="//*[text()='Additional Endorsements']/ancestor::table[1]/parent::div/preceding-sibling::div[1]//*[text()='Endorsements']")	
	public List<WebElement> Endorsements;
	
	@FindBy(how=How.XPATH,using="//*[@fieldref='Cov20LossOfUseEndInput.Indicator']")
	public List<WebElement>  Cov20LossOfUseEndInput_Indicator;
	
	@FindBy(how=How.XPATH,using="//*[@fieldref='Cov5RentLeasePermissionInput.Indicator']")
	public List<WebElement>  Cov5RentLeasePermissionInput_Indicator;
	
	@FindBy(how=How.XPATH,using="//*[@fieldref='Cov23ALienholderMortgInput.Indicator']")
	public List<WebElement>  Cov23ALienholderMortgInput_Indicator;
	
	@FindBy(how=How.XPATH,using="//*[@fieldref='CovDeprWaiverLeasedVehInput.Indicator']")
	public List<WebElement>  CovDeprWaiverLeasedVehInput_Indicator;
	
	@FindBy(how=How.XPATH,using="//*[@fieldref='Cov44FamilyProtectionInput.Indicator']")
	public List<WebElement>  Cov44FamilyProtectionInput_Indicator;
	
	@FindBy(how=How.XPATH,using="//*[@fieldref='CovDeprWaiverInput.Indicator']")
	public List<WebElement>  CovDeprWaiverInput_Indicator;		
	
	@FindBy(how=How.XPATH,using="//*[text()='Policy Level Endorsements']")
	public WebElement PolicyLevelEndorsements;
		
	@FindBy(how=How.XPATH,using="//*[@fieldref='Cov27LiabDamageNOAInput.Indicator']")
	public WebElement  Cov27LiabDamageNOAInput_Indicator;
	
	@FindBy(how=How.XPATH,using="//*[@fieldref='CovOneDedEndInput.Indicator']")
	public WebElement  CovOneDedEndInput_Indicator;
	
	@FindBy(how=How.XPATH,using="//*[@class='g-btn-text'][contains(text(),'Next')]")
	public WebElement Next;
	
	
}
