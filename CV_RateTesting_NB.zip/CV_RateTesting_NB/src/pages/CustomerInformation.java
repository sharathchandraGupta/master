package pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

public class CustomerInformation {
	
	WebDriver driver;
	public CustomerInformation( WebDriver webdriver) {
		driver=webdriver;
		PageFactory.initElements(driver, this);
		
	}
	
	@FindBy(how=How.XPATH,using="//*[@fieldref='LegalNamesInput.Name']")
	public WebElement leagalName;
		
	@FindBy(how=How.XPATH,using="//*[@fieldref='AccountInput.PhoneAreaCode']")
	public WebElement isdcode;
		
	@FindBy(how=How.XPATH,using="//*[@fieldref='AccountInput.PhoneNumber']")
	public WebElement phonenumber;
	
	@FindBy(how=How.XPATH,using="//*[@fieldref='AccountInput.Address']")
	public WebElement postalcode;
	
	@FindBy(how=How.XPATH,using="//img[@class='g-btn-img-loneIcon'][3]")
	public WebElement addresssearch;
	
	@FindBy(how=How.XPATH,using="//*[@fieldref='OperationInput.TypeSelection']")
	public WebElement ibccode;
		
	@FindBy(how=How.XPATH,using="//*[@fieldref='OperationInput.CADRevenue']")
	public WebElement revenue;
	
	@FindBy(how=How.XPATH,using="//*[@class='g-btn-text'][contains(text(),'Next')]")
	public WebElement next;
	

	
	
	

	
};
