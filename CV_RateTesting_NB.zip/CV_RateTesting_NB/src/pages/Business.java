package pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

public class Business {
	
	WebDriver driver;
	public Business( WebDriver webdriver) {
		driver=webdriver;
		PageFactory.initElements(driver, this);
		
	}

	@FindBy(how=How.XPATH,using="//*[@fieldref='PolicyInput.PropertyOrLiabilityClaims']")
	public WebElement propertyLiabilityClaims;
	
	@FindBy(how=How.XPATH,using="//*[@fieldref='LineCommercialAutoInput.InceptionYear']")
	public WebElement InceptionYear;
		
	@FindBy(how=How.XPATH,using="//*[@id='d8D01D2ABC751402B823958D3705E01EA177_4_1_anchorId']/div[2]/span")
	public WebElement next;
		
	
	
	
};
