package utils;

public class Parameters {
	

	public static  String LineCrimeInput;
	public static String TestCaseName;
	public static String flag;
	public static String userName;
	public static String password;	
	public static String coverage;
	public static String AppPremium;
	public static String RaterWorkbookPremium;
	public static String PolicyNumber;
	public static Double BuildingPremium;
	public static Double ContentsPremium;
	public static String CoverageLimit;
	public static String EffectiveDate;
	public static String customerName;
	public static String leagalName;
	public static String isdCode;
	public static Double phoneNumber;
	public static String postalCode;
	public static String ibcCode;
	public static int revenue;
	public static String brokerName;
	public static String currentInsurer;
	public static int yearBusinessEstablished;
	public static int fullTimeEmploys;
	public static String YearsCurrentInsurer;
	
	public static String NewVenture;
	public static String commercialProperty;
	public static String inlandMarineInput;
	public static String businessInterruptionInput;
	public static String propertyLiabilityClaims;
	public static String typeOfConstruction;
	public static int noOfStoreys;
	public static int yearBuilt;
	public static int area;
	public static String liability;
	public static int BuildingLimit;
	public static int BusinessPersonalProperty;
	public static String TCID;
	public static String CommercialAutoCurrentInsurer;	
	public static String MultiLinePolicy;	
	public static int Vehicle_CV_Count;
	public static int Vehicle_NonOwned_Count;
//	public static int Vehicle_PPV_Count;
	public static String VIN;
	public static String VVIN_Flag;
	
	//Commercial Vehicle parameters
	public static String CV_VehicleType;
	public static String CV_Year;
	public static String CV_Make;
	public static String CV_Model;
	public static String CV_TypeOfCommercialUse;
	public static String CV_CommoditiesCarried;
	public static String CV_ToolsAndEquipmentOnly;
	public static String CV_RadiusOfOperation;
	public static String CV_ListPriceNew;
	public static int InceptionYears;
	public static String CV_Trailer_PulledBy;
	public static String CV_Trailer_LocationOfUse;
	public static String PurchaseDate;
	
//	Non Owned Vehicle Details
	public static String Non_VehicleType;
	public static String Non_TypeOfCommercialUse;
	public static String Non_CommoditiesCarried;	
	public static String Non_RadiusOfOperation;
	public static String Non_Trailer_PulledBy;
	public static String Non_Trailer_LocationOfUse;
	public static String Non_VehicleWeight;
	
//	PPV Vehicle parameters
	/*public static String PPV_Year;
	public static String PPV_Make;
	public static String PPV_Model;
	public static String WinterTires;
	public static String MonthsInUS;
	public static String RightHandDrive;
//	public static String PPV_RateByValue;
	public static String PPV_VehicleValue;*/
	public static String CV_RateByValue;
//	Details for Adding Driver
	public static String FirstName;
	public static String LastName;
	public static String MiddleName;
	public static String Gender;
	public static String DateOfBirth;
	public static String MaritalStatus;
	public static String Province;
	public static String LicenseNumber;
	public static String LicenseClass;
	public static String DateAchieved;
	public static String DriverID;
	public static String Assignment;	
	public static String AddConvention;
	public static String AddConvention_Desc_Type;
	public static String AddConvention_Date;
	public static String Driver_ReTraining;
	public static String StudentawayfromHome;		
	public static String HouseHold;
	public static String OwnerShipType;
	public static String LocationOfUse;
	public static String AnnualKilometers;
	public static String DrivingBusinessUse_Percentage;
	public static String DailyKMOneWay;
	public static String VehicleValue;	
	public static String NonOwnedInput_Type;
	public static String SameUseClassAs;
	public static String ExposureDays;
	public static String Limit;	
	public static int DriversToBeAdded;
	public static String AddSuspension;
	public static String AddSuspension_Desc_Type;
	public static String AddSuspension_Date;
	public static String AddSuspension_ReinstatementDate;
	public static String AddConviction_OffenceDate;
	
	
	//Vehicle-Driver Driver Assignment
	public static String Vehicles_For_Driver_Assignment;
	public static String No_Driver_Assignment;
	public static String Driver_Assignment;	
	public static String Assignment_ForDriver;
	public static String Assignment_YearVehicleAndCommodityExp;
	
	
	//Details for Claims	
	public static int No_of_Claims_ToBeAdded;
	public static String Claim_Date;
	public static String Claim_Desc_Of_Loss;
	public static String Claim_Vehicle;
	public static String Claim_AssignLoss;
	public static String Claim_TotalPaid;
	public static String Claim_Reserve;
	public static String Claim_Reserve_Type;
	public static String Claim_Driver;

	//Details for Coverage	
	public static String Additional_Endorsment_Coverages;
	public static String Cover_TPL_BodilyInjury_Flag;
	public static String Cover_TPL_BodilyInjury_Value;
	public static String Cover_TPL_PropertyDamage_Flag;
	public static String Cover_TPL_PropertyDamage_Value;	
	public static String Cover_DirectCompensation_Flag;	
	public static String Cover_DirectCompensation_Value;	
	public static String Cover_AccidentalBenifits_Flag;
	public static String Cover_UninsuredAutomobile_Flag;
	
	public static String Cover_AllPerals_Flag;
	public static String Cover_AllPerals_Value;
	public static String Cover_Collision_Flag;
	public static String Cover_Collision_Value;
	public static String Cover_Comprehensive_Flag;
	public static String Cover_Comprehensive_Value;
	public static String Cover_SpecifiedPerils_Flag;
	public static String Cover_SpecifiedPerils_Value;
	
	
	
	public static String Cover_20_Lossof_UseEndt_Flag;
/*	public static String Cover_20_Lossof_UseEndt_Value;
	public static String Cover_43_DepreciationWaiver;
	public static String Cover_44R_FamilyProtection;*/
	
	
	public static String Cover_Endorsements_Select_Flag;
	public static String Cover_Endorsment_Coverages_ToSelect;
	public static String Cover_Endorsements_UnSelect_Flag;
	public static String Cover_Endorsment_Coverages_ToUnSelect;
	
	public static String Cover_Collision;
	public static String Cover_Comprehensive;
	public static String Additional_Endorsment_Coverages_Flag;
	public static String DriverTraining;
	
	public static String DriverTraining_CompldtedDate;
	public static String DriverReTraining_CompldtedDate;
	public static String Orginal_Leasee_Owner;
	public static String MonthsInUS;
	//public static Object MonthsInUS;
	public static String CV_LocationOfUse_PostalCode;
	
	
	

	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
}
