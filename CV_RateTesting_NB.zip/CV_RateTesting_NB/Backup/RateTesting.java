package rating;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.event.KeyEvent;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.concurrent.TimeUnit;

import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.apache.poi.xwpf.usermodel.XWPFDocument;
import org.apache.poi.xwpf.usermodel.XWPFRun;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.edge.EdgeDriver;
import org.testng.Assert;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;

import Reporting.Reports;
import utils.DataManager;
import utils.Parameters;
import utils.Reusable_Methods;

public class RateTesting {

	ExtentReports extent;
	ExtentTest test;
	XWPFDocument docx;
	XWPFRun run ;
	FileOutputStream out;
	public static WebDriver driver;

	String projPath = System.getProperty("user.dir");
	String path="";

	@BeforeTest
	public void initData() {				
		System.out.println();
		extent = Reports.GetExtent();				
		path = "\\\\NBFC.COM\\departments\\QA\\Northbridge_QA\\IRCA_Rate_Testing_CV\\RateTesting\\TestData\\CV_RateTest_DataSheet.xlsx";				
		new DataManager(path,"poc");
	}

	@BeforeClass
	// Launch the application thru IE browser
	public void launchApplication() throws InvalidFormatException, IOException, AWTException, InterruptedException {

		try {
			System.setProperty("webdriver.edge.driver","\\\\NBFC.COM\\departments\\QA\\IRCA Automation\\RateTesting\\Browsers\\MicrosoftWebDriver.exe");
			driver = new EdgeDriver();
			driver.get("http://azcde04pasvm01:8080/Express/default.aspx");
			driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
			Thread.sleep(5000);
			Robot r = new Robot();
			r.keyPress(KeyEvent.VK_ENTER);
			r.keyRelease(KeyEvent.VK_ENTER);
			Thread.sleep(2000);
		} catch (Exception e) {
			System.out.println("Failed to login");
			e.printStackTrace();
		}
	}

	// Call Login
	@Test 
	public void test() throws InterruptedException, FileNotFoundException {

		// DataManager DM = new DataManager();
		Reusable_Methods RM = new Reusable_Methods(driver);
		Thread.sleep(2000);
		int rnunmber = DataManager.rowNumber;

		for (int row = 1; row < rnunmber; row++) {
			DataManager.readData(row);			
			System.out.println("Execution Row:" + row);

			if (Parameters.flag.equalsIgnoreCase("Y")) {
				test = extent.createTest(Parameters.TCID, "");
				 docx = new XWPFDocument();
				 run = docx.createParagraph().createRun();
				 out = new FileOutputStream(".\\Screenshots\\"+Parameters.TCID+".docx");
				DataManager.readData(row);
				try {
					// Call Login
					System.out.println("Starated Login");
					DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
					Date date = new Date();
					
					if(row>1){
						driver.get("http://azcde04pasvm01:8080/Express/default.aspx");
						driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
						Thread.sleep(5000);
						Robot r = new Robot();
						r.keyPress(KeyEvent.VK_ENTER);
						r.keyRelease(KeyEvent.VK_ENTER);
						Thread.sleep(2000);
					}
					System.out.println("Execution Start Time: " + dateFormat.format(date));
					test.pass("Enter the Login Details");					
					modules.Login login = new modules.Login(driver,test);
					login.populateLogin(docx,run,out);
					test.pass("Login Successfully");	

					// Verfiy Page Dashboard
					boolean flag = RM.verify_PageTitle(driver, "Dashboard");
					try {
						Assert.assertEquals(flag, true);
						test.pass("Verify the dashboard page");
					} catch (AssertionError e) {
						System.out.println("Failed to Navigate to Dashboard page");
					}

					// Call Customer Search
					System.out.println("Starated CustomerSearch");
					test.pass("Enter the Customer details to search");
					modules.CustomerSearch customerSearch = new modules.CustomerSearch(driver);
					customerSearch.customerSearch(docx,run,out);
					test.pass("Click on OK and Verfiy the Customer Page");

					// VerfiyCustomerPage
					flag = false;
					flag = RM.verify_PageTitle(driver, "Customer");
					try {
						Assert.assertEquals(flag, true);
						test.pass("Sucessfully Navigated to Customer Page");
					} catch (AssertionError e) {
						e.printStackTrace();
						test.fail("Failed to Navigate Customer Page");
						System.out.println("Failed to Navigate to Customer page");
					}

					// Call Customer Information
					System.out.println("Starated CustomerInformation");
					test.pass("Enter the customer details");
					modules.CustomerInformation customerInformation = new modules.CustomerInformation(driver);
					customerInformation.customerInformation(docx,run,out);
					test.pass("Click on Next and Verfiy the Submission Page");
					
					// VerfiySubmissionPage
					flag = false;
					flag = RM.verify_PageTitle(driver, "Submission");
					try {
						Assert.assertEquals(flag, true);
						test.pass("Sucessfully Navigated to Submission Page");
						System.out.println("Sucessfully Navigated to Submission Page");
					} catch (AssertionError e) {
						e.printStackTrace();
//						test.fail("Failed to Navigate Submission Page");
						System.out.println("Failed to Navigate to Submission page");
					}

					// Call Submission
					test.pass("Enter the Submission details");
					modules.Submission submission = new modules.Submission(driver);
					submission.submission(docx,run,out);
																				
					// VerfiyBusinessPage
					flag = false;
					flag = RM.verify_PageTitle(driver, "Business");
					try {
						Assert.assertEquals(flag, true);
						test.pass("Sucessfully Navigated to Business Page");
						test.pass("Click on Next and Verify the Business page");
						
					} catch (AssertionError e) {
						e.printStackTrace();
//						test.fail("Failed to Navigate Business Page");
						System.out.println("Failed to Navigate to Business page");
					}

					// Call Business Module
					test.pass("Enter the Business details");
					modules.Business Business = new modules.Business(driver);
					Business.business(docx,run,out);
					test.pass("Click On Next and Verify the Location page");
					
					// Verfiy Location Page
					
					flag = false;
					flag = RM.verify_PageTitle(driver, "Location");
					try {											
						if(flag){
						// Call Location
						test.pass("Enter the Location details");
						modules.Location Location = new modules.Location(driver);
						Location.location();
						test.pass("Click on Next and Verfiy the Premium Page");
						}
					} catch (Exception e) {
						
						System.out.println("Failed to Navigate to Location page");
					}

				// Call Add Vehicle 
					modules.AddVehicle AddVehicle = new modules.AddVehicle(driver);
					AddVehicle.AddVehicle(docx,run,out);

					// Call Add Driver
					Thread.sleep(3000);
					test.pass("Enter the Location details");
					modules.AddDriver AddDriver = new modules.AddDriver(driver);
					AddDriver.AddDriver(docx,run,out);					
					
					// Call Driver_Assignment 
					test.pass("Enter the Location details");
					modules.Assignment Assignment = new modules.Assignment(driver);
					Assignment.Driver_Assignment(docx,run,out);
					
					// Call Claims 
					test.pass("Enter the Location details");
					modules.ClaimInfo ClaimInfo = new modules.ClaimInfo(driver);
					ClaimInfo.ClaimInfo();

					// Call Coverage
					modules.Coverage Coverage = new modules.Coverage(driver);
					Coverage.Coverage_New();

				} catch (Exception e) {
					DataManager.writeData(path,row, 4, "Skip");
				} finally {

					// LogOut
					try {
						DateFormat dateFormater = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
						Date date1 = new Date();
						docx.write(out);
						out.flush();
						out.close();
//						DataManager.writeData(path, row,36, dateFormater.format(date1));
						System.out.println("Execution End Time: " + dateFormater.format(date1));
						JavascriptExecutor js = (JavascriptExecutor) driver;
						WebElement ele_LogOut = driver.findElement(By.id("id_LogOut"));
						js.executeScript("arguments[0].scrollIntoView(true);", ele_LogOut);
						Thread.sleep(2000);
						ele_LogOut.click();
						Thread.sleep(5000);
					} catch (Exception e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				}

			} else {
				continue;
			}
		}
	}

	@AfterTest
	public void tearDown() {
		extent.flush();
		//driver.quit();

	}
}
