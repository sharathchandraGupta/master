package com.org.adsales;

import java.util.LinkedHashSet;

public class AllStringCombinations {
	public static void main(String[] args){
		LinkedHashSet<String> combination = new LinkedHashSet<>();
		String str = "ab";
		int size = str.length();
		
		for(int i=0;i<str.length();i++){
//			System.out.println(str.substring(i,i+1));
			String s = str.substring(i,i+1);
//			char to = s.charAt(0); 
			char[] cha = str.toCharArray();
			for(int j=0;j<str.length();j++){
				
				cha[i]=s.charAt(0);
				String b = new String(s);
				combination.add(b);
			}
			
			
		}
		
		for(String s:combination){
			System.out.println(s);
		}
	}

}
